List of figures:

Fig. 1 - Study setup from Biorender
Fig. 2A - Distribution of Age and Sex <- Excel.  Keep?
Fig. 2B - Antibiotcs susceptibility category <- Excel Keep
Fig. 3 - Distribution of susceptibility <- Excep FIXME to ggplot
Fig. 4a Cluster UMAP.
Fig. 4B Heatmap zone diameters
Fig. 5A Overall correct v.s. number of antibiotics & significance level, 
Fig. 5B Overall correct+ME+VME v.s. significanve level (fixed 6 antibiotics)
Fig. 6A Overall correct v.s ref+modes & number of antibiotics (10% fixed)
Fig. 6B Overall correct v.s significancelevel & number of antibiotics 
Fig. 7A Antibiotics correct v.s. number of antibiotics
Fig. 7A Antibiotics correct+ME+VME v.s. number of antibiotics
Fig. 8A-D Antibiotics ME-rate/VME-rate/Correcly susceptible/correctly resistent v.s. significanveLevel
Fig. 9A Heatmap VME
Fig. 9B Heatmap ME
Fig. 9C Heatmap SIR (EUCAST)
Fig. 10A Antibiotic VME-rate v.s numberofAntibiotics(all comb/at least one per group) 
Fig. 10B Antibiotic ME-rate v.s numberofAntibiotics(all comb/at least one per group)


Fig. S1A ME vs Significance level
Fig. S1B VME vs Significance level
Fig. S2A-D Antibiotics ME-rate/VME-rate/Correcly susceptible/correctly resistent v.s. mode
Fig. S3A Heatmap zone diameters annotated with beta-lactamase group
Fig. S3B Heatmap EUCAST SIR


For ESCMD
Fig. E1 Study setup
Fig  E2 




