library(pheatmap)
library(ggplot2)
library(grid)
library(gridExtra)


test = matrix(rnorm(200), 20, 10)
test[1:10, seq(1, 10, 2)] = test[1:10, seq(1, 10, 2)] + 3
test[11:20, seq(2, 10, 2)] = test[11:20, seq(2, 10, 2)] + 2
test[15:20, seq(2, 10, 2)] = test[15:20, seq(2, 10, 2)] + 4
colnames(test) = paste("Test", 1:10, sep = "")
rownames(test) = paste("Gene", 1:20, sep = "")

dim(test)
dim(matrix(ifelse(test > 1, "*", ""),nrow(test)))

heatmap1 <- pheatmap(test)
heatmap2 <- pheatmap(test,display_numbers = matrix(ifelse(test > 1, "ATU", ""),nrow(test)))

# Function to add a frame to the heatmap's gtable
add_frame_to_heatmap <- function(heatmap_gtable) {
  # Get the current gtable and add a rectangle around the entire plot area
  heatmap_gtable <- gtable::gtable_add_grob(heatmap_gtable, 
                                            grob = rectGrob(gp = gpar(lwd = 2, col = "black", fill = NA)),
                                            t = 1, l = 1, b = nrow(heatmap_gtable), r = ncol(heatmap_gtable))
  return(heatmap_gtable)
}

# Add frames to each heatmap's gtable
heatmap1_with_frame <- add_frame_to_heatmap(heatmap1$gtable)
heatmap2_with_frame <- add_frame_to_heatmap(heatmap2$gtable)

# Arrange the plots with frames around each of them
grid.arrange(
  heatmap1_with_frame, heatmap2_with_frame,
  ncol = 2
)

###############################


# Load necessary libraries
library(ggplot2)

# Set up a 10x10 matrix of random values
matrix_data <- matrix(runif(100), nrow=10)

# Create data frame for ggplot
df <- expand.grid(x = 1:10, y = 1:10)
df$value <- as.vector(matrix_data)

# Function to divide each cell into two parts along the diagonal
df$half_color <- ifelse(df$x > df$y, df$value, NA)
df$half_white <- ifelse(df$x <= df$y, df$value, NA)

# Plot with ggplot
ggplot(df) +
  geom_tile(aes(x = x, y = y, fill = half_color), width = 1, height = 1) +
  geom_tile(aes(x = x, y = y, fill = half_white), width = 1, height = 1, color = "white") +
  scale_fill_gradient(low = "white", high = "blue") +
  theme_minimal() +
  coord_fixed() +
  theme(axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank())


#############################################################

# Load necessary libraries
library(grid)

# Set up a 10x10 matrix with random values for the heatmap
matrix_data <- matrix(runif(100), nrow = 10)

# Define a color function based on the values (you can adjust the colors as needed)
color_func <- function(val) {
  rgb(val, 0, 1 - val)  # Example: Color transitions from red to blue
}

# Function to draw each cell with a diagonal split
draw_heatmap_cell <- function(x, y, val) {
  # Define the vertices of the two triangles (split by the diagonal)
  color1 <- color_func(val)  # Color for the top half (based on value)
  color2 <- "white"  # Color for the bottom half (white)
  
  # Define the points for the top triangle (half-colored)
  points1 <- data.frame(
    x = c(x, x + 1, x + 1),
    y = c(y, y, y + 1)
  )
  
  # Define the points for the bottom triangle (white)
  points2 <- data.frame(
    x = c(x, x, x + 1),
    y = c(y + 1, y, y + 1)
  )
  
  # Draw the top half (colored)
  grid.polygon(x = points1$x, y = points1$y, gp = gpar(fill = color1, col = NA))
  
  # Draw the bottom half (white)
  grid.polygon(x = points2$x, y = points2$y, gp = gpar(fill = color2, col = NA))
}

# Set up the plotting area
grid.newpage()

# Loop through each cell of the matrix and draw the heatmap with the diagonal split
for (i in 1:nrow(matrix_data)) {
  for (j in 1:ncol(matrix_data)) {
    draw_heatmap_cell(j - 1, i - 1, matrix_data[i, j])
  }
}


##########################
library(ggplot2)

# Example data
df <- expand.grid(X = 1:5, Y = 1:5)
df$Value <- runif(nrow(df))
df$Marker <- sample(c(0, 1), nrow(df), replace = TRUE)  # Binary marker

ggplot(df, aes(X, Y, fill = Value)) +
  geom_tile() + 
  geom_point(data = subset(df, Marker == 1), aes(X, Y), shape = 8, size = 4, color = "red") + # Adding markers
  scale_fill_gradient(low = "blue", high = "red")

################################
library(ComplexHeatmap)

# Create heatmap
ht = Heatmap(matrix)

# Create annotation layer
ha = HeatmapAnnotation(
  foo = anno_mark(at = c(1, 3), labels = c("*", "#"))
)

# Combine heatmap and annotation
ht + ha


