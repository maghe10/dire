source('common.R')



# ------------------------------------------------------------------
# Example: read exported order and trees to build pheatmaps elsewhere
# ------------------------------------------------------------------
readClusterPhenotypeForPheatmap <- function(data_dir = processedRootRcommon,
                                      export_dir = file.path(processedRootRcluster),
                                      prefix = "clusterPhenotype",
                                      mode = "Mode-A") {
  row_info <- read.csv2(file.path(export_dir, sprintf("%s_row_info.csv", prefix)), stringsAsFactors = FALSE)
  col_info <- read.csv2(file.path(export_dir, sprintf("%s_col_info.csv", prefix)), stringsAsFactors = FALSE)
  
  row_order <- row_info$sample[order(row_info$roworder)]
  col_order <- col_info$antibiotic[order(col_info$colorder)]
  

  # Exact trees if you need them:
  row_hclust <- readRDS(file.path(export_dir, sprintf("%s_row_hclust.rds", prefix)))
  col_hclust <- readRDS(file.path(export_dir, sprintf("%s_col_hclust.rds", prefix)))
  
  list(
    row_info = row_info,
    col_info = col_info,
    row_hclust = row_hclust,
    col_hclust = col_hclust
  )
}

cluster_palette <- function(n) {
  base <- c("red", "blue", "green", "purple", "orange",
            "pink", "brown", "cyan", "yellow", "gray")
  setNames(base[seq_len(n)], as.character(seq_len(n)))
}

gradient_red <- function(n = 100) colorRampPalette(c("white", "red"))(n)
gradient_orange <- function(n = 100) colorRampPalette(c("white", "orange"))(n)
gradient_green_yellow_red <- function(n = 100) colorRampPalette(c("red", "yellow", "green"))(n)




make_pheatmap <- function(mat,
                          annotation_row = NULL,
                          annotation_colors = NULL,
                          color = gradient_red(),
                          show_rownames = FALSE,
                          show_colnames = TRUE,
                          cluster_rows = TRUE,
                          cluster_cols = TRUE,
                          legend = FALSE,
                          display_numbers = NULL,
                          fontsize_row = 4,
                          fontsize_col = 10,
                          fontsize_number = 8,
                          clustering_callback = NULL) {
  
  args <- list(
    mat = mat,
    clustering_method = "ward.D2",
    annotation_row = annotation_row,
    annotation_colors = annotation_colors,
    color = color,
    show_rownames = show_rownames,
    show_colnames = show_colnames,
    cluster_rows = cluster_rows,
    cluster_cols = cluster_cols,
    legend = legend,
    border_color = NA,
    fontsize_row = fontsize_row,
    fontsize_col = fontsize_col,
    fontsize_number = fontsize_number,
    main = ""
  )
  
  if (!is.null(display_numbers)) {
    args$display_numbers <- display_numbers
  }
  
  if (!is.null(clustering_callback)) {
    args$clustering_callback <- clustering_callback
  }
  
  do.call(pheatmap::pheatmap, args)
}



EXAMPLE <- function()
{
  aList <- readClusterPhenotypeForPheatmap()
  
  cluster_rows = FALSE
  cluster_cols = FALSE
  row_info <- aList$row_info
  col_info <- aList$col_info
  row_hc <- aList$row_hclust
  col_hc <- aList$col_hclust
  mm <- read.csv2(file.path(processedRootRcommon,"modelmillimetertableRescaled.csv"), stringsAsFactors = FALSE)
  rownames(mm) <- as.character(mm$sample)
  mm$sample <- NULL
  
  annotation_row <- row_info %>%
    mutate(
      sample = as.character(sample),
      cluster = as.character(cluster),
      ESBL = as.character(ESBL)
    ) %>%
    arrange(roworder) %>%
    tibble::column_to_rownames("sample") %>%
    dplyr::select(cluster, ESBL)
  
  # force exact displayed order for the legend
  cluster_levels <- as.character(unique(row_info$cluster[order(row_info$roworder)]))
  

  annotation_colors <- list(
    cluster = setNames(cluster_palette(length(cluster_levels)), cluster_levels),
    ESBL = c(
      "A"   = "yellow",
      "M"   = "orange",
      "A+M" = "red",
      "C"   = "darkred",
      "no"  = "white"
    )
  )
  
  row_ordered_samples <- as.character(row_info$sample[order(row_info$roworder)])
  col_ordered_antibiotics <- as.character(col_info$antibiotic[order(col_info$colorder)])
  
  stopifnot(all(row_ordered_samples %in% rownames(mm)))
  stopifnot(all(col_ordered_antibiotics %in% colnames(mm)))
  
  mm_ordered <- mm[row_ordered_samples, col_ordered_antibiotics, drop = FALSE]
  

  head(mm_ordered)
  
  #primary pheatmap with dendrograms
  make_pheatmap(
    mat = mm,
    cluster_rows = row_hc,
    cluster_cols = col_hc,
    color = rev(gradient_red()),
    annotation_row = annotation_row,
    annotation_colors = annotation_colors
  )

  #Other pheatmap without dendrograms but preserve4d order
  make_pheatmap(
    mat = mm_ordered,
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    color = rev(gradient_red()),
    annotation_row = annotation_row,
    annotation_colors = annotation_colors
  )
  
  
}

