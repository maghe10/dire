library(dplyr)
library(readr)
library(tidyr)
library(pheatmap)
library(factoextra)
library(ggplot2)
library(patchwork)
source("common.R")
# ============================================================
# Configuration
# ============================================================

MODEL_ANTIBIOTICS <- ANTIBIOTICS
BETA_LACTAMS <- c("AMP", "AMC", "PIP", "TZP", "CAZ", "CRO", "CTX", "FEP")

cluster_palette <- function(n) {
  base <- c("red", "blue", "green", "purple", "orange",
            "pink", "brown", "cyan", "yellow", "gray")
  setNames(base[seq_len(n)], as.character(seq_len(n)))
}

gradient_red <- function(n = 100) colorRampPalette(c("white", "red"))(n)
gradient_orange <- function(n = 100) colorRampPalette(c("white", "orange"))(n)
gradient_green_yellow_red <- function(n = 100) colorRampPalette(c("red", "yellow", "green"))(n)

# ============================================================
# IO
# ============================================================

read_semicolon_csv <- function(path) {
  read.csv2(path, check.names = FALSE, stringsAsFactors = FALSE)
}

load_cluster_data <- function(data_dir = ".") {
  list(
    atu                  = read_semicolon_csv(file.path(data_dir, "atu.csv")),
    breakpoints          = read_semicolon_csv(file.path(data_dir, "breakpoints.csv")),
    demographics         = read_semicolon_csv(file.path(data_dir, "demographicstable.csv")),
    esbl                 = read_semicolon_csv(file.path(data_dir, "esbl.csv")),
    mm_full              = read_semicolon_csv(file.path(data_dir, "millimetertable.csv")),
    mm_model             = read_semicolon_csv(file.path(data_dir, "modelmillimetertable.csv")),
    mm_full_rescaled     = read_semicolon_csv(file.path(data_dir, "millimetertableRescaled.csv")),
    mm_model_rescaled    = read_semicolon_csv(file.path(data_dir, "modelmillimetertableRescaled.csv")),
    sir_mode_a           = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-A.csv")),
    sir_mode_b           = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-B.csv")),
    sir_mode_c           = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-C.csv"))
  )
}

# ============================================================
# Small utilities
# ============================================================

as_sample_rownames <- function(df) {
  stopifnot("sample" %in% colnames(df))
  rn <- df$sample
  df <- as.data.frame(df)
  rownames(df) <- rn
  df
}

select_model_antibiotics <- function(df) {
  df %>%
    as.data.frame() %>%
    select(sample, all_of(MODEL_ANTIBIOTICS))
}

drop_sample_column <- function(df) {
  df %>% select(-sample)
}

safe_rescale_01 <- function(df_numeric) {
  out <- df_numeric
  for (j in seq_len(ncol(out))) {
    x <- out[[j]]
    rng <- range(x, na.rm = TRUE)
    if (is.infinite(rng[1]) || is.infinite(rng[2]) || isTRUE(all.equal(rng[1], rng[2]))) {
      out[[j]] <- 0
    } else {
      out[[j]] <- (x - rng[1]) / (rng[2] - rng[1])
    }
  }
  out
}

sir_to_numeric <- function(sir_df) {
  out <- sir_df
  out[out == "S"] <- 1
  out[out == "I"] <- 0.5
  out[out == "R"] <- 0
  out[] <- lapply(out, as.numeric)
  out
}

wrap_pheatmap <- function(ph) {
  patchwork::wrap_elements(full = ph$gtable)
}

panel_box_theme <- theme(
  plot.background = element_rect(fill = NA, colour = NA),
  plot.margin = margin(4, 4, 4, 4)
)

# ============================================================
# Data extractors
# ============================================================

read_millimeter_table <- function(dat) {
  dat$mm_model %>%
    select_model_antibiotics() %>%
    as_sample_rownames()
}

read_rescaled_millimeter_table <- function(dat, use_existing = TRUE) {
  if (use_existing) {
    dat$mm_model_rescaled %>%
      select_model_antibiotics() %>%
      as_sample_rownames()
  } else {
    mm <- read_millimeter_table(dat)
    mm_only <- drop_sample_column(mm)
    mm_scaled <- safe_rescale_01(mm_only)
    out <- cbind(sample = rownames(mm), mm_scaled)
    as_sample_rownames(out)
  }
}

read_sir_antibiotics_model <- function(dat, mode = "Mode-A") {
  sir_tbl <- switch(
    mode,
    "Mode-A" = dat$sir_mode_a,
    "Mode-B" = dat$sir_mode_b,
    "Mode-C" = dat$sir_mode_c,
    stop("Unknown mode: ", mode)
  )
  
  sir_tbl %>%
    select_model_antibiotics() %>%
    as_sample_rownames()
}

read_atu_antibiotics_model <- function(dat) {
  dat$atu %>%
    select_model_antibiotics() %>%
    as_sample_rownames()
}

read_esbl_annotation <- function(dat) {
  esbl <- dat$esbl %>%
    mutate(
      ESBL = case_when(
        ESBL_CARBA ~ "C",
        ESBL_A & ESBL_M ~ "A+M",
        ESBL_M ~ "M",
        ESBL_A ~ "A",
        TRUE ~ "no"
      )
    ) %>%
    select(sample, ESBL)
  
  rownames(esbl) <- esbl$sample
  esbl$sample <- NULL
  esbl
}

fetch_tables <- function(dat, mode = "Mode-A", use_existing_rescaled = TRUE) {
  mm <- read_millimeter_table(dat)
  mm_rescaled <- read_rescaled_millimeter_table(dat, use_existing = use_existing_rescaled)
  sir <- read_sir_antibiotics_model(dat, mode = mode)
  sir_num <- sir_to_numeric(drop_sample_column(sir))
  
  list(
    SIR = sir_num,
    RESCALEDMM = drop_sample_column(mm_rescaled),
    MM = drop_sample_column(mm)
  )
}

# ============================================================
# Clustering + annotations
# ============================================================

clusters_and_annotation <- function(data_frame, k) {
  data_mat <- as.matrix(data_frame)
  
  hc <- hclust(dist(data_mat), method = "ward.D2")
  clusters <- cutree(hc, k = k)
  
  annotation <- data.frame(
    Cluster = factor(clusters, levels = as.character(seq_len(k))),
    row.names = rownames(data_frame)
  )
  
  annotation_colors <- list(
    Cluster = cluster_palette(k)
  )
  
  list(
    data = data_mat,
    hc = hc,
    clusters = clusters,
    annotation = annotation,
    annotation_colors = annotation_colors
  )
}

decorate_with_esbl <- function(caa, dat) {
  esbl <- read_esbl_annotation(dat)
  
  esbl <- esbl[rownames(caa$annotation), , drop = FALSE]
  caa$annotation$ESBL <- factor(esbl$ESBL, levels = c("A", "M","A+M","C", "no"))
  
  caa$annotation_colors$ESBL <- c(
    "A" = "yellow",
    "M" = "orange",
    "A+M" = "red",
    "C" = "darkred",
    "no" = "white"
  )
  caa
}

decorate_with_demographics <- function(caa, dat) {
  demo <- dat$demographics %>%
    select(sample, sex, age)
  rownames(demo) <- demo$sample
  demo$sample <- NULL
  
  demo <- demo[rownames(caa$annotation), , drop = FALSE]
  demo$sex <- factor(demo$sex)
  
  caa$annotation <- cbind(caa$annotation, demo)
  
  caa$annotation_colors$sex <- c("F" = "#E78AC3", "M" = "#8DA0CB")
  
  caa
}

# ============================================================
# Plot helpers
# ============================================================

make_cluster_plot <- function(caa, title = NULL) {
  fviz_cluster(
    list(data = caa$data, cluster = caa$clusters),
    palette = unlist(caa$annotation_colors$Cluster),
    ellipse.type = "convex",
    geom = "point",
    show.clust.cent = TRUE
  ) +
    ggtitle(title %||% "")
}

`%||%` <- function(x, y) if (is.null(x)) y else x

make_pheatmap <- function(mat,
                          annotation_row = NULL,
                          annotation_colors = NULL,
                          color = gradient_red(),
                          show_rownames = FALSE,
                          show_colnames = TRUE,
                          cluster_rows = TRUE,
                          cluster_cols = TRUE,
                          legend = FALSE,
                          display_numbers = NULL,
                          fontsize_row = 4,
                          fontsize_col = 10,
                          fontsize_number = 8) {
  
  args <- list(
    mat = mat,
    clustering_method = "ward.D2",
    annotation_row = annotation_row,
    annotation_colors = annotation_colors,
    color = color,
    show_rownames = show_rownames,
    show_colnames = show_colnames,
    cluster_rows = cluster_rows,
    cluster_cols = cluster_cols,
    legend = legend,
    border_color = NA,
    fontsize_row = fontsize_row,
    fontsize_col = fontsize_col,
    fontsize_number = fontsize_number,
    main = ""
  )
  
  if (!is.null(display_numbers)) {
    args$display_numbers <- display_numbers
  }
  
  do.call(pheatmap::pheatmap, args)
}

# ============================================================
# Choosing k
# ============================================================

estimate_optimal_number_of_clusters <- function(data_matrix, max_k = 10, seed = 123) {
  set.seed(seed)
  
  list(
    wss = fviz_nbclust(data_matrix, hcut, method = "wss", hc_method = "ward.D2") +
      labs(subtitle = "Elbow method"),
    silhouette = fviz_nbclust(data_matrix, hcut, method = "silhouette", hc_method = "ward.D2") +
      labs(subtitle = "Silhouette method"),
    gap = fviz_nbclust(data_matrix, hcut, method = "gap_stat", nboot = 50, hc_method = "ward.D2") +
      labs(subtitle = "Gap statistic method")
  )
}

# ============================================================
# Main workflow
# ============================================================

make_cluster_and_heatmaps <- function(data_dir = ".",
                                      mode = "Mode-A",
                                      primary_table = "RESCALEDMM",
                                      k = 8,
                                      add_esbl = TRUE,
                                      add_demographics = FALSE) {
  dat <- load_cluster_data(data_dir)
  tables <- fetch_tables(dat, mode = mode)
  
  stopifnot(primary_table %in% names(tables))
  
  primary <- tables[[primary_table]]
  caa <- clusters_and_annotation(primary, k = k)
  
  if (add_esbl) {
    caa <- decorate_with_esbl(caa, dat)
  }
  if (add_demographics) {
    caa <- decorate_with_demographics(caa, dat)
  }
  
  cluster_plot <- make_cluster_plot(caa)
  
  primary_heatmap <- make_pheatmap(
    mat = primary,
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = rev(gradient_red()),
    cluster_rows = TRUE,
    cluster_cols = TRUE,
    legend = FALSE
  )
  
  row_order <- primary_heatmap$tree_row$order
  col_order <- primary_heatmap$tree_col$order
  
  # SIR heatmap with ATU stars
  sir_tbl <- tables$SIR
  atu_tbl <- read_atu_antibiotics_model(dat) %>% drop_sample_column()
  
  display_numbers <- matrix(
    ifelse(as.matrix(atu_tbl), "\u2217", ""),
    nrow = nrow(atu_tbl),
    dimnames = dimnames(atu_tbl)
  )
  
  sir_heatmap <- make_pheatmap(
    mat = sir_tbl[row_order, col_order, drop = FALSE],
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, col_order, drop = FALSE]
  )
  
  combined_1 <- (
    (cluster_plot + panel_box_theme) +
      (wrap_pheatmap(primary_heatmap) & panel_box_theme)
  ) +
    plot_layout(ncol = 2) +
    plot_annotation(tag_levels = "A")
  
  combined_2 <- wrap_pheatmap(sir_heatmap) & panel_box_theme
  
  list(
    data = dat,
    tables = tables,
    cluster = caa,
    row_order = row_order,
    col_order = col_order,
    cluster_plot = cluster_plot,
    primary_heatmap = primary_heatmap,
    sir_heatmap = sir_heatmap,
    combined_cluster_primary = combined_1,
    combined_sir = combined_2
  )
}

EXAMPLE <- function()
{
  result <- make_cluster_and_heatmaps(
      data_dir = processedRootRcommon,
      mode = "Mode-A",
      primary_table = "RESCALEDMM",
      k = 6,
      add_esbl = TRUE,
      add_demographics = FALSE
    )
  print(result$combined_cluster_primary)
  print(result$combined_sir)
  
  #Beta-lactam-only subset example:
  beta_tbl <- result$tables$RESCALEDMM[, BETA_LACTAMS, drop = FALSE]
  beta_caa <- clusters_and_annotation(beta_tbl,6)
  beta_caa <- decorate_with_esbl(beta_caa, result$data)
  ph_beta <- make_pheatmap(
     beta_tbl,
    annotation_row = beta_caa$annotation,
    annotation_colors = beta_caa$annotation_colors,
    color = rev(gradient_red())
  )
  print(wrap_pheatmap(ph_beta))
}

# ============================================================
# Example usage
# ============================================================

# result <- make_cluster_and_heatmaps(
#   data_dir = "path/to/csv_dir",
#   mode = "Mode-A",
#   primary_table = "RESCALEDMM",
#   k = 8,
#   add_esbl = TRUE,
#   add_demographics = TRUE
# )
#
# print(result$combined_cluster_primary)
# print(result$combined_sir)

# Beta-lactam-only subset example:
# beta_tbl <- result$tables$RESCALEDMM[, BETA_LACTAMS, drop = FALSE]
# beta_caa <- clusters_and_annotation(beta_tbl, k = 4)
# beta_caa <- decorate_with_esbl(beta_caa, result$data)
# ph_beta <- make_pheatmap(
#   beta_tbl,
#   annotation_row = beta_caa$annotation,
#   annotation_colors = beta_caa$annotation_colors,
#   color = rev(gradient_red())
# )
# print(wrap_pheatmap(ph_beta))