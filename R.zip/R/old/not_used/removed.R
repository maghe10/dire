# countIncorrect <-
#   function (answerDataFrame,
#             predictionDataFrame,
#             vme = FALSE)
#   {
#     resultFrame <- data.frame(answerDataFrame)
#     resultFrame[] <- as.integer(0)
#     
#     
#     for (row in 1:nrow(resultFrame)) {
#       for (col in 1:ncol(resultFrame)) {
#         incorrect = 0
#         sentence <- predictionDataFrame[[row, col]]
#         words = unlist(strsplit(sentence, "[[:space:]]"))
#         for (word in words) {
#           if (!length(grep("_SR", word)) > 0) {
#             # Not ending with _SR => compare with _R or _S
#             if (length(grep("_R", word)) > 0) {
#               opposite = paste(substr(word, 1, 4), "S", sep = "")
#             }
#             else {
#               opposite = paste(substr(word, 1, 4), "R", sep = "")
#             }
#             if (length(grep(opposite, answerDataFrame[[row, col]])) > 0) {
#               predR = length(grep("_R", word)) > 0
#               if (xor(x = vme, y = predR)) {
#                 incorrect <- incorrect + 1
#               }
#             }
#           }
#         }
#         #      print(matches)
#         resultFrame[[row, col]] <- as.integer(incorrect)
#       }
#     }
#     resultFrame
#   }


# countAmbiguous <- function (answerDataFrame, predictionDataFrame) {
#   resultFrame <- data.frame(answerDataFrame)
#   resultFrame[] <- as.integer(0)
#   
#   
#   for (row in 1:nrow(resultFrame)) {
#     for (col in 1:ncol(resultFrame)) {
#       matches = 0
#       sentence <- predictionDataFrame[[row, col]]
#       words = unlist(strsplit(sentence, "[[:space:]]"))
#       for (word in words) {
#         if (length(grep("_SR", word)) > 0) {
#           # Ending with _SR => ambiguous
#           matches <- matches + 1
#         }
#         resultFrame[[row, col]] <- as.integer(matches)
#       }
#     }
#   }
#   resultFrame
# }

# countPredicted <- function(predictionDataFrame, technical = FALSE)
# {
#   resultFrame <- data.frame(predictionDataFrame)
#   resultFrame[] <- 0
#   
#   tmp <- apply(predictionDataFrame, c(1, 2), function(x) {
#     res = 0
#     if (x != "<empty>") {
#       words = unlist(strsplit(x, "[[:space:]]"))
#       if (!technical) {
#         res = length(grep("_SR", words, invert = TRUE))
#       } else {
#         res = length(words)
#       }
#     }
#     res
#   })
#   resultFrame <- data.frame(tmp)
# }




# countCorrect <- function (answerDataFrame, predictionDataFrame)
# {
#   resultFrame <- data.frame(answerDataFrame)
#   resultFrame[] <- as.integer(0)
#   
#   
#   for (row in 1:nrow(resultFrame)) {
#     for (col in 1:ncol(resultFrame)) {
#       matches = 0
#       sentence <- predictionDataFrame[[row, col]]
#       words = unlist(strsplit(sentence, "[[:space:]]"))
#       for (word in words) {
#         if (length(grep(word, answerDataFrame[[row, col]])) > 0) {
#           matches <- matches + 1
#         }
#         resultFrame[[row, col]] <- as.integer(matches)
#       }
#     }
#   }
#   resultFrame
# }

#index <- 6
# EXTRACT_SUMMARY_OLD <- function(technical)
# {
#   allStats <- NULL
#   for(index in range){
#     comparison <- readOutputFrame(k=index,type = "comparison",folder = TEMP_FOLDER)
#     predictions <-readOutputFrame(k=index,type = "predictions",folder = TEMP_FOLDER)
#     correct <- readOutputFrame(k=index,type = "correct",folder = TEMP_FOLDER)
#     vme <- readOutputFrame(k=index,type = "vme",folder = TEMP_FOLDER)
#     me <- readOutputFrame(k=index,type = "me",folder = TEMP_FOLDER)
#
#
#     mean(comparison,na.rm = TRUE)
#
#     meanVME <- data.frame(apply(vme,2, mean))
#     colnames(meanVME)[1] = paste("vme",index,sep="_")
#     meanME <- data.frame(apply(me,2, mean))
#     colnames(meanME)[1] = paste("me",index,sep="_")
#
#     percentage <- sum(vme)/sum(predictions)
#     percentage <- sum(me)/sum(predictions)
#     sum(correct)/sum(predictions)
#
#     sum_vme <- apply(vme,2, sum)
#     sum_of_sums_vme <- apply(sum_vme,1,sum)
#
#
#     meanComparison <- data.frame(apply(comparison,2, mean))
#
#     colnames(meanComparison)[1] = paste("mean",index,sep="_")
#
#     for (signi in signis) {
#       if(technical){
#         correct_type <-  "correct_conformal_technical"
#         prediction_type <- "predictions_conformal_technical"
#         comparison_type <- "comparison_conformal_technical"
#       } else {
#         correct_type <-  "correct_conformal_clinical"
#         prediction_type <- "predictions_conformal_clinical"
#         comparison_type <- "comparison_conformal_clinical"
#       }
#       comparisonConf <- readOutputFrame(k=index,signi,type = comparison_type,folder = TEMP_FOLDER)
#       df <- data.frame(apply(comparisonConf,2, mean,na.rm = TRUE))
#       meanComparison <- cbind (meanComparison,df)
#       colnames(meanComparison)[ncol(meanComparison)] = paste("mean",index,signi,sep="_")
#     }
#
#     df <- data.frame(apply(meanComparison,2, mean))
#
#     print(df)
#     if(is.null(allStats)){
#       allStats <- df
#       rownames(allStats)[1] <- "pred"
#       rownames(allStats)[2:(length(signis)+1)] = fixSigni(signis)
#     }
#     else {
#       allStats <- cbind(allStats,df)
#     }
#     colnames(allStats)[ncol(allStats)] <- index
#
#   }
#
#   if(technical){
#     writeOutputFrame(allStats, k=index,type = "all_technical")
#   }
#   else {
#     writeOutputFrame(allStats, k=index,type = "all_clinical")
#   }
#
# }

genericCount <-
  function (answerDataFrame,
            predictionDataFrame,ab=NULL,countFunction,...)
  {
    resultFrame <- applyElementWise(predictionDataFrame,answerDataFrame,function(p,a){
      count = 0
      sentence <- p
      if(!is.character(p)){
        print(ab)
        print(answerDataFrame)
        print(predictionDataFrame)
        print(p)
        print(a)
      }
      if(sentence != "<empty>"){
        words = unlist(strsplit(sentence, "[[:space:]]"))
        for (word in words) {
          if(is.null(ab) || length(grep(ab, word)) > 0)
          {
            if(countFunction(word,a,...)){
              count <- count + 1
            }
          }
        }
      }
      as.integer(count)
    })
    resultFrame
  }



