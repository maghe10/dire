library(tidyverse)
dim(starwars)
var <- seq(1, nrow(df))
mutate(df, new = var)
starwars %% across()
df <- starwars %>% select(name, height, mass)


x <- data.frame(cbind(x1 = 3, x2 = c(4:1, 2:5)))
dimnames(x)[[1]] <- letters[1:8]
y <- x
unlist(apply(x,1,
             function(u){
               unlist(apply(y,2,
                            function(v){
                              u + v  
                            }))
             }))
x+y

magnusSum(x,y)
magnusSum <- function(a,b)
{
  a+b
}

yyy <- as_tibble(predictionDataFrame) %>% mutate(across(c(1,2),strsplit,"[[:space:]]"))

xxx <- yyy %>% mutate(across(c(1,2),unlist))



df  %>% mutate_each(funs(tolower))


magnusCompare <-function(answerDataFrame,predictionDataFrame)
{
  predictionDataFrame
  words = unlist(strsplit(predictionDataFrame, "[[:space:]]"))
}
