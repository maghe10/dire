# clusterPhehotype.R
#
# Minimal export script for phenotype clustering:
# - row_info.csv: sample, roworder, cluster, ESBL
# - col_info.csv: antibiotic, colorder
# - row_hclust.rds: exact rotated row tree
# - col_hclust.rds: exact column tree
#
# Assumes common.R defines processedRootRcommon.

suppressPackageStartupMessages({
  library(dplyr)
  library(tibble)
})

source("common.R")

BETA_LACTAMS <- c("AMP", "AMC", "PIP", "TZP", "CAZ", "CRO", "CTX", "FEP")
MODEL_ANTIBIOTICS <- c(
  "AMP", "AMC", "PIP", "TZP", "CAZ", "CRO", "CTX",
  "FEP", "CIP", "OFX", "LVX", "MFX", "GEN", "TOB"
)

# lower rank = placed higher up
ESBL_PRIORITY <- c(
  "C"   = 1,
  "A+M" = 2,
  "M"   = 3,
  "A"   = 4,
  "no"  = 5
)

read_semicolon_csv <- function(path) {
  read.csv2(path, check.names = FALSE, stringsAsFactors = FALSE)
}

load_cluster_data <- function(data_dir = processedRootRcommon) {
  list(
    atu               = read_semicolon_csv(file.path(data_dir, "atu.csv")),
    esbl              = read_semicolon_csv(file.path(data_dir, "esbl.csv")),
    mm_model          = read_semicolon_csv(file.path(data_dir, "modelmillimetertable.csv")),
    mm_model_rescaled = read_semicolon_csv(file.path(data_dir, "modelmillimetertableRescaled.csv")),
    sir_mode_a        = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-A.csv")),
    sir_mode_b        = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-B.csv")),
    sir_mode_c        = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-C.csv"))
  )
}

as_sample_rownames <- function(df) {
  stopifnot("sample" %in% colnames(df))
  rn <- as.character(df$sample)
  out <- as.data.frame(df)
  rownames(out) <- rn
  out
}

select_model_antibiotics <- function(df) {
  df %>% dplyr::select(sample, dplyr::all_of(MODEL_ANTIBIOTICS))
}

drop_sample_column <- function(df) {
  dplyr::select(df, -sample)
}

read_rescaled_millimeter_table <- function(dat) {
  dat$mm_model_rescaled %>%
    select_model_antibiotics() %>%
    as_sample_rownames() %>%
    drop_sample_column()
}

read_esbl_annotation <- function(dat) {
  esbl <- dat$esbl %>%
    mutate(
      ESBL = case_when(
        ESBL_CARBA ~ "C",
        ESBL_A & ESBL_M ~ "A+M",
        ESBL_M ~ "M",
        ESBL_A ~ "A",
        TRUE ~ "no"
      )
    ) %>%
    dplyr::select(sample, ESBL)
  
  rownames(esbl) <- as.character(esbl$sample)
  esbl$sample <- NULL
  esbl
}

read_sir_antibiotics_model <- function(dat, mode = "Mode-A") {
  sir_tbl <- switch(
    mode,
    "Mode-A" = dat$sir_mode_a,
    "Mode-B" = dat$sir_mode_b,
    "Mode-C" = dat$sir_mode_c,
    stop("Unknown mode: ", mode)
  )
  
  sir_tbl %>%
    select_model_antibiotics() %>%
    as_sample_rownames() %>%
    drop_sample_column()
}

reorder_hclust_by_weights <- function(hc, weights) {
  dend <- as.dendrogram(hc)
  dend <- reorder(dend, wts = weights, agglo.FUN = mean)
  as.hclust(dend)
}

make_row_weights <- function(mat,
                             esbl,
                             esbl_priority = ESBL_PRIORITY) {
  mm_mean <- rowMeans(mat, na.rm = TRUE)
  esbl_rank <- unname(esbl_priority[as.character(esbl)])
  esbl_rank[is.na(esbl_rank)] <- max(esbl_priority, na.rm = TRUE) + 1
  
  # ESBL dominates, mm breaks ties within ESBL.
  esbl_rank * 1000 + mm_mean
}

renumber_clusters_topdown <- function(clusters, row_names_ordered) {
  old_in_order <- unique(clusters[row_names_ordered])
  map <- setNames(seq_along(old_in_order), old_in_order)
  out <- unname(map[as.character(clusters)])
  names(out) <- names(clusters)
  out
}

cluster_phenotype <- function(data_dir = processedRootRcommon,
                              mode = "Mode-A",
                              k = 6,
                              out_dir = file.path(processedRootRcommon, "clusterPhenotype"),
                              prefix = "clusterPhenotype") {
  dat <- load_cluster_data(data_dir)
  
  # Primary matrix for clustering/order: rescaled model millimeters.
  primary <- read_rescaled_millimeter_table(dat)
  primary <- primary[, intersect(MODEL_ANTIBIOTICS, colnames(primary)), drop = FALSE]
  
  # Main clustering on full rescaled model millimeters.
  row_hc <- hclust(dist(primary), method = "ward.D2")
  
  esbl_ann <- read_esbl_annotation(dat)
  esbl_ann <- esbl_ann[rownames(primary), , drop = FALSE]
  
  row_weights <- make_row_weights(primary, esbl_ann$ESBL)
  row_hc_rot <- reorder_hclust_by_weights(row_hc, row_weights)
  row_names_ordered <- rownames(primary)[row_hc_rot$order]
  
  clusters <- cutree(row_hc, k = k)
  clusters <- renumber_clusters_topdown(clusters, row_names_ordered)
  
  make_col_weights <- function(mat) {
    colMeans(mat, na.rm = TRUE)
  }
  
  # Column clustering on all model antibiotics from the same RESCALEDMM source.
  col_hc <- hclust(dist(t(primary)), method = "ward.D2")
  col_weights <- make_col_weights(primary)
  col_hc_rot <- reorder_hclust_by_weights(col_hc, col_weights)
  col_names_ordered <- colnames(primary)[col_hc_rot$order]
  
  
  
  row_info <- tibble(
    sample = rownames(primary),
    cluster = unname(clusters[rownames(primary)]),
    ESBL = unname(esbl_ann[rownames(primary), "ESBL"])
  ) %>%
    left_join(
      tibble(sample = row_names_ordered, roworder = seq_along(row_names_ordered)),
      by = "sample"
    ) %>%
    arrange(roworder)
  
  col_info <- tibble(
    antibiotic = col_names_ordered,
    colorder = seq_along(col_names_ordered)
  )
  
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  
  write.csv2(row_info, file.path(out_dir, sprintf("%s_row_info.csv", prefix)), row.names = FALSE)
  write.csv2(col_info, file.path(out_dir, sprintf("%s_col_info.csv", prefix)), row.names = FALSE)
  saveRDS(row_hc_rot, file.path(out_dir, sprintf("%s_row_hclust.rds", prefix)))
  saveRDS(col_hc_rot, file.path(out_dir, sprintf("%s_col_hclust.rds", prefix)))
  
  invisible(list(
    row_info = row_info,
    col_info = col_info,
    row_hclust = row_hc_rot,
    col_hclust = col_hc,
    primary = primary,
    sir = read_sir_antibiotics_model(dat, mode = mode)
  ))
}


# ------------------------------------------------------------------
# Run
# ------------------------------------------------------------------
ALL <- function(){
  result <- cluster_phenotype(
    data_dir = processedRootRcommon,
    mode = "Mode-A",
    k = 6,
    out_dir = file.path(processedRootRcluster),
    prefix = "clusterPhenotype"
  )
}
