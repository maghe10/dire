###########

source(file = 'common.R')
library(scales)

# FIXME migrate to readxl
library(openxlsx)

library(writexl)
#install.packages('writexl') 


#install.packages('xlsx')     
#library(xlsx)   


MODE_A <- "Mode-A"
MODE_B <- "Mode-B"
MODE_C <- "Mode-C"

MODES <- c(MODE_A,MODE_B,MODE_C)

METRICS <- c("correct","ME","VME")
METRICS_LOWER_CASE <- c("correct","me","vme")

format_percent <- function(x) {
  formatted <- format(round(x * 100, 10), trim = TRUE, scientific = FALSE)
  paste0(formatted, "%")
}

fixSigni <- function(signi)
{
  if(is.null(signi) || is.na(signi)){
    rv <- "non-conformal"
  } else {
    sTmp <- paste("0.", signi, sep = "")
    dTmp <- as.double(sTmp) * 10
#    rv <- format(round(dTmp, 3), nsmall = 3)
    rv <- format_percent(dTmp)
  }
  rv
}


getModeRootStatisticsFolder <- function(mode)
{
  paste(modelDirectory,
        "output",
        mode,
        "statistics",
        sep = "/")
}


readStatisticsFrameCSV  <-
  function(name,
           subfolder="",mode)
  {
    file <- paste(getModeRootStatisticsFolder(mode),subfolder,paste(name,"csv",sep="."),  sep = "/")
    
    read.csv2(file = file,check.names = FALSE)
  } 


writeStatisticsExcel <- function(frames,name,shortName,mode="")
  {
  if(mode==""){
    shortFile <- paste(name,".xlsx",sep="") 
  } else {
    shortFile <- paste(name,"-",mode,".xlsx",sep="") 
  }
  
  file <- paste(manuscriptDirectory,shortFile,  sep = "/")

  if(is.data.frame(frames)){
    aList <- list()
    if(mode==""){
      sheetName <- paste(shortName,sep="")
    } else {
      sheetName <- paste(shortName,"-",shortMode(mode),sep="")
    }
    aList[[sheetName]] <- frames
    frames <- aList
  } else { # list of frames
      if(mode==""){
        names(frames) <- paste(shortName,names(frames),sep="-")
      }
      else {
        names(frames) <- paste(shortName,names(frames),shortMode(mode),sep="-")
      }
  }
#  print(file)
#  print(frame)
  write_xlsx(x = frames, path=file)
  #write.xlsx( x= frames, file=file) 
#  print("ok")
  }


#name<-"allStats" 
#subfolder<-""
writeAllModes <-function(name,shortName,subfolder="")
{
  aList <- list()
  for(mode in MODES){
    frame <- readStatisticsFrameCSV(name,subfolder,mode)
    aList[[shortMode(mode)]] <- frame
  }

  writeStatisticsExcel(aList,name=name,shortName=shortName)
}


shortMode <-function(mode)
{
  rv <- ""
  if(nchar(mode)>0){
    rv <- substr(mode,nchar(mode),nchar(mode))
  }
  rv
}
  

writeSeveral <- function(names,shortName,subfolder,mode)
{
  aList <- list()
  for(name in names){
    frame <- readStatisticsFrameCSV(name,subfolder,mode)
    aList[[name]] <- frame
  }
  
  writeStatisticsExcel(aList,shortName,shortName,mode)
}


ALL <- function()
{
  subfolder <- ""
  names <- c("abStatistics-4","abStatistics-5","abStatistics-6","abStatistics-7","abStatistics-8")

  mode <- MODE_A
  shortName <- "VME-ME-CORRECT"
  name <- "abStatistics-6"
  #  writeAllModes("allStats","allStats")
  for( mode in MODES) {
#    writeSeveral(c("abStatistics-4","abStatistics-5","abStatistics-6","abStatistics-7","abStatistics-8"),"VME-ME-CORRECT","",mode)
    aList <- list()
    for(name in names){
      frame <- readStatisticsFrameCSV(name,subfolder,mode)
      
      frame <- frame[,order(match(colnames(frame), c("antibiotic",METRICS)))]
      aList[[name]] <- frame
    }
    
    writeStatisticsExcel(aList,shortName,shortName,mode)
  }
  
#  writeAllModes("signiStatisticsDetails-0025","signiDetails-0025")
#  writeAllModes("signiStatisticsDetails-005","signiDetails-005")
#  writeAllModes("signiStatisticsDetails-01","signiDetails-01")
  
  antibioticsMetricMode()
  
#  clinicalSigniStatistics()
#  technicalSigniStatistics()
  
#  f<- readStatisticsFrameCSV("signiStatisticsDetails-005","",MODE_A)
#  writeStatisticsExcel(f,"signiStatisticsDetails-005","signiDetails-005",MODE_A)
  
  for( mode in MODES) {
    name <- "abStatistics-correct"
    f<- readStatisticsFrameCSV(name,"",mode)
    f <- f[,c("antibiotic","4","5","6","7","8")]
    writeStatisticsExcel(f,name,name,mode)
  }
  
  
  
  
# signiNonsigniDetailsCompared("01")
#  signiDetailsCompared("005")
#  signiDetailsCompared("0025")
  nonconfDetailsCompared()
  signiDetailsModes(index=4)
  signiDetailsModes(index=6)
  signiDetailsModes(index=8)
  correctPredictions()
  
#   signiDetailsIndex()
   mixedDetailIndex()
#  mixedDetailIndexAb("AMC")
  
  compareGenotypePhenotype()
  amrStatistics()
}




nonconfDetailsCompared <-function()
{
  aList <- list()
#  index <- 4
#  mode <- MODE_A
  inName <- "nonconformalStatisticsDetails"
  outName <- "nonconformalStatisticsDetailsCompared" 
    
  compare_class <-  readStatisticsFrameCSV(inName,"",MODES[[1]])$compare_class
  for(index in c(4,6,8)){
    modesAsColumnsFrame <- data.frame(compare_class = compare_class)
    for(mode in MODES){
      frame <- readStatisticsFrameCSV(inName,"",mode)
#      frame <- frame[order(match(frame$compare_class, METRICS_LOWER_CASE)),]
#      frame$compare_class <- METRICS
      
      col <- frame[,colnames(frame)==as.character(index)]
      modesAsColumnsFrame <- cbind(modesAsColumnsFrame,col)
      colnames(modesAsColumnsFrame)[ncol(modesAsColumnsFrame)] <- mode
    }
    modesAsColumnsFrame <- modesAsColumnsFrame[order(match(modesAsColumnsFrame$compare_class, METRICS_LOWER_CASE)),]
    modesAsColumnsFrame$compare_class <- METRICS
    aList[[as.character(index)]] <- modesAsColumnsFrame
  }
  writeStatisticsExcel(aList,outName,"nonconfCompared") 
}



signiDetailsModes <-function(index = 6)
{
  aList <- list()
#  signi <- "0025"
#  index <- 6
#  mode <- MODE_A
  nameOut <- paste("signiStatisticsDetailsModes",index,sep="-")
  
  signis <- c("01","005","0025")
  
  for(signi in signis){
    nameIn <- paste("signiStatisticsDetails",signi,sep="-")
    compare_class <-  readStatisticsFrameCSV(nameIn,"",MODES[[1]])$compare_class
    modesAsColumnsFrame <- data.frame(compare_class = compare_class)
    for(mode in MODES){
      frame <- readStatisticsFrameCSV(nameIn,"",mode)
      
      col <- frame[,colnames(frame)==as.character(index)]
      modesAsColumnsFrame <- cbind(modesAsColumnsFrame,col)
      colnames(modesAsColumnsFrame)[ncol(modesAsColumnsFrame)] <- mode
    }
    modesAsColumnsFrame <- modesAsColumnsFrame[modesAsColumnsFrame$compare_class %in% METRICS_LOWER_CASE,]
    modesAsColumnsFrame <- modesAsColumnsFrame[order(match(modesAsColumnsFrame$compare_class, METRICS_LOWER_CASE)),]
    modesAsColumnsFrame$compare_class <- METRICS
    aList[[signi]] <- modesAsColumnsFrame
  }
  writeStatisticsExcel(aList,nameOut,paste("signiModes",index,sep="-")) 
}



signiNonsigniDetailsCompared <-function(signi="01")
{
  aList <- list()
#  signi <- "01"
#  index <- 4
  nameOut <- paste("signiStatisticsDetailsCompared",signi,sep="-")
  nameIn <- paste("signiStatisticsDetails",signi,sep="-")

  compare_class <-  readStatisticsFrameCSV(nameIn,"",MODES[[1]])$compare_class
  for(mode in MODES){
    modesAsColumnsFrame <- data.frame(compare_class = compare_class)
    for(index in c(4:8)){
      frame <- readStatisticsFrameCSV(nameIn,"",mode)
      #frame <- frame[order(match(frame$compare_class, METRICS_LOWER_CASE)),]
      #frame$compare_class <- METRICS
      
      col <- frame[,colnames(frame)==as.character(index)]
      modesAsColumnsFrame <- cbind(modesAsColumnsFrame,col)
      colnames(modesAsColumnsFrame)[ncol(modesAsColumnsFrame)] <- index
    }
    aList[[as.character(mode)]] <- modesAsColumnsFrame
  }
  writeStatisticsExcel(aList,nameOut,paste("signiCompared",signi,sep="-")) 
}


correctPredictions <- function() {
  
#  signi <- "01"
  aList <- list()
  for (mode in MODES) {
    signis = c("01","005","0025")
    nameInNonSigni <- "nonconformalStatisticsDetails"

    frame <- readStatisticsFrameCSV(nameInNonSigni,"",mode)
    frame <- frame[frame$compare_class=="correct",colnames(frame) %in% 4:8]
    rownames(frame) <- fixSigni(NULL)
    for(signi in signis){
      nameInSigni <- paste("signiStatisticsDetails",signi,sep="-")
      signiFrame <- readStatisticsFrameCSV(nameInSigni,"",mode)
      signiFrame <- signiFrame[signiFrame$compare_class=="correct",colnames(signiFrame) %in% 4:8]
      rownames(signiFrame) <- fixSigni(signi)
      frame <- rbind(frame,signiFrame)
    }
    frame <- cbind(rownames(frame),frame)
    colnames(frame)[1] <- "significance level"
    aList[[as.character(mode)]] <- frame
  }
  writeStatisticsExcel(aList,"correctPredictions","correct")
}


signiDetailsIndex <- function() {
  for (mode in MODES) {
    aList <- list()
    for(index in c(4,6,8)){
      name = paste("signiStatisticsIndex",index,sep="-")
      frame <- readStatisticsFrameCSV(name,"",mode)
      frame <-frame[frame$compare_class %in% METRICS_LOWER_CASE,]
      frame <- frame[order(match(frame$compare_class, METRICS_LOWER_CASE)),]
      frame$compare_class <- METRICS
      
      aList[[as.character(index)]] <- frame
    }
    writeStatisticsExcel(aList,"signiStatisticsIndex","signiIndex",mode)
  }
}


mixedDetailIndex <- function()
{
  for (mode in MODES) {
    aList <- list()
    for(index in c(4,6,8)){
      name = paste("signiStatisticsIndex",index,sep="-")
      frame <- readStatisticsFrameCSV(name,"",mode)
    
      name = paste("statisticsIndex",index,sep="-")
      frame2 <- readStatisticsFrameCSV(name,"",mode)

      frame <- cbind(frame2,frame[,2:ncol(frame)])
      frame <-frame[frame$compare_class %in% METRICS_LOWER_CASE,]
      frame <- frame[order(match(frame$compare_class, METRICS_LOWER_CASE)),]
      frame$compare_class <- METRICS
      
      colnames(frame)[colnames(frame)=="crude"] <- "non-conformal"
      colnames(frame)[colnames(frame)=="0.100"] <- "10%"
      colnames(frame)[colnames(frame)=="0.050"] <- "5%"
      colnames(frame)[colnames(frame)=="0.025"] <- "2.5%"
      
      aList[[as.character(index)]] <- frame
    }
    writeStatisticsExcel(aList,"mixedDetailIndex","mixedDetailIndex",mode)
  }
}

mixedDetailIndexAb <- function(antibiotics)
{
  for (mode in MODES) {
    aList <- list()
    for(index in c(4,6,8)){
      name = paste("signiStatisticsIndex",index,antibiotics,sep="-")
      frame <- readStatisticsFrameCSV(name,"",mode)
      
      name = paste("statisticsIndex",index,antibiotics,sep="-")
      frame2 <- readStatisticsFrameCSV(name,"",mode)
      
      frame <- cbind(frame2,frame[,2:ncol(frame)])
      frame <-frame[frame$compare_class %in% METRICS_LOWER_CASE,]
      
      colnames(frame)[colnames(frame)=="crude"] <- "non-conformal"
      
      aList[[as.character(index)]] <- frame
    }
    writeStatisticsExcel(aList,paste("mixedDetailIndex",antibiotics,sep="-"),paste("mixedDetailIndex",antibiotics,sep="-"),mode)
  }
}


antibioticsMetricMode <- function(index  = 6)
{
  metrics <- METRICS
  aList <- list() 
  for (metric in metrics){
    name <- paste("abStatistics",metric,sep="-")
    f<- readStatisticsFrameCSV(name,"",MODES[[1]])
    antibiotics <- f$antibiotic
    frame <- data.frame(antibiotics = antibiotics)
    for(mode in MODES){
      name <- paste("abStatistics",metric,sep="-")
      f<- readStatisticsFrameCSV(name,"",mode)
      col <- f[,as.character(index)]
      frame <- cbind(frame,col)
      colnames(frame)[ncol(frame)] <- mode
    }
    aList[[metric]] <- frame
  }  
  writeStatisticsExcel(aList,paste("antibioticsMetricMode",index,sep="-"),paste("abMetricMode",index,sep="-"))
}

  
clinicalSigniStatistics <- function()
{
  aList <- list()
  name <- "clinicalSigniStatistics"
  for(mode in MODES){
    frame <- readStatisticsFrameCSV(name,"",mode)
    classOrder <- c("crude","0.100","0.050","0.025")
    frame <- frame[frame$compare_class %in% classOrder,colnames(frame) %in% c("compare_class",as.character(4:8))]
    frame <- frame[order(match(frame$compare_class,classOrder)),]

    frame[frame=="crude"] <- "non-conformal"
    aList[[mode]] <- frame
  }
  writeStatisticsExcel(aList,name,"clinical")
}

technicalSigniStatistics <- function()
{
  aList <- list()
  name <- "technicalSigniStatistics"
  for(mode in MODES){
    frame <- readStatisticsFrameCSV(name,"",mode)
    classOrder <- c("crude","0.100","0.050","0.025")
    frame <- frame[frame$compare_class %in% classOrder,colnames(frame) %in% c("compare_class",as.character(4:13))]
    frame <- frame[order(match(frame$compare_class,classOrder)),]
    frame[frame=="crude"] <- "non-conformal"
    aList[[mode]] <- frame
  }
  writeStatisticsExcel(aList,name,"technical")

}

amrStatistics <-function()
{
  indir <- paste(processedRootRassembly, "amrfinder", sep="/")
  aList <- list()

  frame <- read.xlsx(xlsxFile = paste(sep="",indir, "\\" ,assemblymethod,"_allSamplesAndAllGenes_",amrfinderDatabase,".xlsx"))
  colnames(frame) <- gsub("\\.", " ", colnames(frame))
  aList[["allSamplesAndAllGenes"]] <- frame

  frame <- read.xlsx(xlsxFile = paste(sep="",indir, "\\" ,assemblymethod,"_classcore-in-samples_",amrfinderDatabase,".xlsx"))
  colnames(frame) <- gsub("\\.", " ", colnames(frame))
  aList[["classCoreInSamples"]] <- frame

  frame <- read.xlsx(xlsxFile = paste(sep="",indir, "\\" ,assemblymethod,"_genes-in-samples_",amrfinderDatabase,".xlsx"))
  colnames(frame) <- gsub("\\.", " ", colnames(frame))
  aList[["allGenesInSamples"]] <- frame

  frame <- read.xlsx(xlsxFile = paste(sep="",indir, "\\" ,assemblymethod,"_betalactam-core-genes-in-samples_",amrfinderDatabase,".xlsx"))
  colnames(frame) <- gsub("\\.", " ", colnames(frame))
  aList[["betalactamCoreInSamples"]] <- frame
  
  
  writeStatisticsExcel(aList,"amrStatistics","amr") 
}

# compareGenotypePhenotype <- function()
# {
#   indir <- paste(processedRootRassembly, "amrfinder", sep="/")
#   aList <- list()
#   for(mode in MODES){
#     frame <- read.csv2(check.names=FALSE,file= paste(sep="",indir, "\\" ,assemblymethod,"_clavulanic-acid_",mode,"_",amrfinderDatabase,".csv"))
#     aList[[shortMode(mode)]] <- frame
#   }
#   writeStatisticsExcel(aList,"clavulanic-acid","ca")
# 
#   aList <- list()
#   for(mode in MODES){
#     frame <- read.csv2(check.names=FALSE,file= paste(sep="",indir, "\\" ,assemblymethod,"_clavulanic-acid-summary_",mode,"_",amrfinderDatabase,".csv"))
#     aList[[shortMode(mode)]] <- frame
#   }
#   writeStatisticsExcel(aList,"clavulanic-acid-summary","ca-summary")
#   
#   aList <- list()
#   for(mode in MODES){
#     frame <- read.csv2(check.names=FALSE,file= paste(sep="",indir, "\\" ,assemblymethod,"_betalactamases_",mode,"_",amrfinderDatabase,".csv"))
#     aList[[shortMode(mode)]] <- frame
#   }
#   writeStatisticsExcel(aList,"betalactamases","betalactamases")
#   
# }
compareGenotypePhenotype <- function()
{
  indir <- paste(processedRootRassembly, "genotype", sep="/")
  names <- c("betalactamases","genotype_phenotype","enzymeFamily_phenotype", "samples_and_genotypes")
  for(name in names){
    frame <- read.csv2(check.names=FALSE,file= paste(sep="",indir, "\\" ,assemblymethod,"_",name,"_",amrfinderDatabase,".csv"))
    writeStatisticsExcel(frame=frame,name,name)
  }
   
}

