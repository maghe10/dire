ROWS <- 99

PATTERN_S <- "^([[:alpha:]]+)_S$"
PATTERN_R <- "^([[:alpha:]]+)_R$"
PATTERN_SR <- "^([[:alpha:]]+)_SR$"

unit_test <- function()
{
  a <- "CRO_S LVX_R TZP_R AMC_R MFX_S GEN_S CTX_S PIP_R FEP_R CAZ_S CIP_S OFX_S TOB_R"
  p <- "CRO_SR LVX_SR TZP_R AMC_S MFX_R GEN_S CTX_SR PIP_SR FEP_R CAZ_R CIP_S"
  
  ok = TRUE
  ok = ok & getAmbiguous(a,p) == "CRO LVX CTX PIP"
  ok = ok & getCorrect(a,p) == "TZP FEP GEN CIP"
  ok = ok & getME(a,p) == "MFX CAZ"
  ok = ok & getVME(a,p) == "AMC"
  ok = ok & getPredictedOrAmbiguous(a,p) == "AMC GEN CIP TZP MFX FEP CAZ CRO LVX CTX PIP"
  ok = ok & getPredicted(a,p) == "AMC GEN CIP TZP MFX FEP CAZ"
  ok = ok & getNotPredicted(a,p) == "OFX TOB"
  ok
}

getNotPredicted <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  a <- unlist(strsplit(a,split=" "))
  allP <- substr(p,1,3)
  allA <- substr(a,1,3)
  paste(allA[!(allA %in% allP)],collapse=" ")
}


getVME <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  a <- unlist(strsplit(a,split=" "))
  # for vme a should be R and p should be S
  sensP <- substr(unlist(regmatches(p, gregexpr(PATTERN_S, p))),1,3)
  resA <- substr(unlist(regmatches(a, gregexpr(PATTERN_R, a))),1,3)
  paste(intersect(sensP,resA),collapse=" ")
}

getME <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  a <- unlist(strsplit(a,split=" "))
  # for vme a should be S and p should be R
  resP <- substr(unlist(regmatches(p, gregexpr(PATTERN_R, p))),1,3)
  sensA <- substr(unlist(regmatches(a, gregexpr(PATTERN_S, a))),1,3)
  paste(intersect(resP,sensA),collapse=" ")
}

getAmbiguous <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  # all that are _SR
  ambP <- substr(unlist(regmatches(p, gregexpr(PATTERN_SR, p))),1,3)
  paste(ambP,collapse=" ")
}

getCorrect <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  a <- unlist(strsplit(a,split=" "))
  # all that are not _SR and are the same
  sensP <- substr(unlist(regmatches(p, gregexpr(PATTERN_S, p))),1,3)
  resA <- substr(unlist(regmatches(a, gregexpr(PATTERN_R, a))),1,3)
  resP <- substr(unlist(regmatches(p, gregexpr(PATTERN_R, p))),1,3)
  sensA <- substr(unlist(regmatches(a, gregexpr(PATTERN_S, a))),1,3)
  
  same <- union(intersect(resA,resP),intersect(sensA,sensP))
  paste(same,collapse=" ")
}

getPredicted <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  # all that are not _SR and are the same
  sensP <- substr(unlist(regmatches(p, gregexpr(PATTERN_S, p))),1,3)
  resP <- substr(unlist(regmatches(p, gregexpr(PATTERN_R, p))),1,3)
  paste(union(sensP,resP),collapse=" ")
}

getPredictedOrAmbiguous <- function(a,p){
  p <- unlist(strsplit(p,split=" "))
  # all that are not _SR and are the same
  sensP <- substr(unlist(regmatches(p, gregexpr(PATTERN_S, p))),1,3)
  resP <- substr(unlist(regmatches(p, gregexpr(PATTERN_R, p))),1,3)
  sensresP <- substr(unlist(regmatches(p, gregexpr(PATTERN_SR, p))),1,3)
  paste(union(sensP,union(resP,sensresP)),collapse=" ")
}




COMPARE_METRICS_VECTOR <-c(
  COMPARE_CORRECT,
  COMPARE_VME,
  COMPARE_ME,
  COMPARE_PREDICTED,
  COMPARE_AMBIGUOUS,
  COMPARE_PREDICTED_OR_AMBIGUOUS,
  COMPARE_NOT_PREDICTED
)

#COMPARE_FUNCTIONS <- c(COMPARE_CORRECT=getCorrect, COMPARE_VME = getVME,COMPARE_ME=getME,COMPARE_PREDICTED=getPredicted,COMPARE_AMBIGUOUS=getAmbiguous,COMPARE_PREDICTED_OR_AMBIGUOUS=getPredictedOrAmbiguous)
COMPARE_FUNCTIONS <- c(getCorrect, getVME,getME,getPredicted,getAmbiguous,getPredictedOrAmbiguous,getNotPredicted)
names(COMPARE_FUNCTIONS)<-COMPARE_METRICS_VECTOR


# see GENERATE_STATISTICS_ALT
#
GENERATE_STATISTICS <- function()
{
  allStats <- data.frame(
    noinputab = integer(),
    metric = character(),
    count = integer(),
    antibiotic = character(),
    significanslevel = numeric()
  )
  
  for(index in range){
    predsFiles <- makeShortFileName("preds",index)
    for(signi in signis){
      predsFiles <- c(predsFiles,makeShortFileName("confpreds",index,signi))
    }
    names(predsFiles) <- c("crude",signis)
    for(predsName in names(predsFiles)){
      predsFile <- predsFiles[[predsName]]
      for ( name in names(COMPARE_FUNCTIONS)){
        newShortName <- paste(substring(predsFile,0,nchar(predsFile)-4),"_",name,".csv",sep="")
        frame <- readOutputFrameShort(shortfile=newShortName,folder=getCompareFolder(MODE))
        frame[is.na(frame)] <- ""
        for(ab in ANTIBIOTICS){
          count = countWords(frame,ab)
          if(predsName=="crude"){
            signi = NA
          }
          else {
            signi <- fixSigni(predsName)
          }
          row <- c (
            as.integer(index),
            name,
            count,
            ab,
            signi)
          allStats[nrow(allStats) + 1, ] <- row
        }
      }
    }
    writeStatisticsFrame(frame = allStats, name = paste("stats_temp",as.integer(index),sep="_"),folder = getStatisticsFolder(MODE))
  }
  writeStatisticsFrame(allStats, name = "allstats",getStatisticsFolder(MODE))
}



#
# @deprecated
GENERATE_SUBSET_STATISTICS <- function(abs)
{
  #abs <- c("AMP","CRO","CIP","TOB")
  word <- paste(abs,collapse="_")
  index <- length(abs)
  
  allStats <- data.frame(
    noinputab = integer(),
    metric = character(),
    count = integer(),
    antibiotic = character(),
    significanslevel = numeric()
  )
  
  predsFiles <- makeShortFileName("preds",index)
  for(signi in signis){
    predsFiles <- c(predsFiles,makeShortFileName("confpreds",index,signi))
  }
  names(predsFiles) <- c("crude",signis)
  for(predsName in names(predsFiles)){
    # predsName <-"crude"
    predsFile <- predsFiles[[predsName]]
    for ( name in names(COMPARE_FUNCTIONS)){
      # name <- "correct"
      newShortName <- paste(substring(predsFile,0,nchar(predsFile)-4),"_",name,".csv",sep="")
      frame <- readOutputFrameShort(shortfile=newShortName,folder=getCompareFolder(MODE))
      frame[is.na(frame)] <- ""
      frame <- frame[,word]
      for(ab in ANTIBIOTICS){
        #ab = "PIP"
        count = countWords(frame,ab)
        if(predsName=="crude"){
          signi = NA
        }
        else {
          signi <- fixSigni(predsName)
        }
        row <- c (
          as.integer(index),
          name,
          count,
          ab,
          signi)
        allStats[nrow(allStats) + 1, ] <- row
      }
    }
  }
  writeStatisticsFrame(allStats, name = paste("allstats",word,sep="-"),getStatisticsBestFolder(MODE))
}


generate_signi_statistics_new <- function()
{
  allStats <- readStatisticsFrame("allstats",getStatisticsFolder(MODE))
  range <- unique(allStats$noinputab)
  
  rows <- unique(allStats$significanslevel)
  rows[is.na(rows)]<-"crude"
  
  percentageFrame <- data.frame(row.names = rows)
  
  
}



generate_signi_statistics <- function(technical=FALSE)
{
  allStats <- readStatisticsFrame("allstats",getStatisticsFolder(MODE))
  range <- unique(allStats$noinputab)
  
  rows <- unique(allStats$significanslevel)
  rows[is.na(rows)]<-"crude"
  
  percentageFrame <- data.frame(row.names = rows)
  
  # Conformal predictions clinical & technical
  for(index in range) {
    percentageRow <- c()
    levels <- unique(allStats$significanslevel)
    subsetIndex <- allStats[allStats$noinputab==index,]
    for (level in levels){
      if(is.na(level)) {
        subset <- subsetIndex[is.na(subsetIndex$significanslevel),]
      }
      else {
        subset <- subsetIndex[!is.na(subsetIndex$significanslevel) & subsetIndex$significanslevel==level,]
      }
      #      print(sum(subset$count))
      if(technical){
        correctTechnical <- subset[subset$metric==COMPARE_CORRECT | subset$metric==COMPARE_AMBIGUOUS,] #   <- FIXME spelling 
        predictedTechnical <- subset[subset$metric==COMPARE_PREDICTED_OR_AMBIGUOUS,]
        percentageTechnical <- sum(correctTechnical$count)/sum(predictedTechnical$count)
        percentage <- percentageTechnical
      }
      else {
        correctClinical <- subset[subset$metric==COMPARE_CORRECT,]
        predictedClinical <- subset[subset$metric==COMPARE_PREDICTED,]
        percentageClinical <- sum(correctClinical$count)/sum(predictedClinical$count)
        percentage <- percentageClinical
      }
      percentageRow <- c(percentageRow,percentage)
      #      print(paste(index,level,percentage,sep=" "))
    }
    percentageFrame <- cbind(percentageFrame,percentageRow)
  }
  colnames(percentageFrame) <- range
  compare_class <- rownames(percentageFrame)
  percentageFrame <- cbind(compare_class,percentageFrame)
  percentageFrame
}


generate_signi_statistics_details <- function(level = "0025")
{
  allStats <- readStatisticsFrame("allstats",getStatisticsFolder(MODE))
  range <- unique(allStats$noinputab)
  
  percentageFrame <- data.frame(row.names = c("correct","amb","vme","me","nopred"))
  
  for(index in range) {
    percentageRow <- c()
    subsetIndex <- allStats[allStats$noinputab==index,]
    if(is.na(level)) {
      subset <- subsetIndex[is.na(subsetIndex$significanslevel),]
    }
    else {
      subset <- subsetIndex[!is.na(subsetIndex$significanslevel) & subsetIndex$significanslevel==fixSigni(level),]
    }
    correct <- sum(subset[subset$metric==COMPARE_CORRECT,]$count)
    amb <- sum(subset[subset$metric==COMPARE_AMBIGUOUS,]$count)
    vme <- sum(subset[subset$metric==COMPARE_VME,]$count)
    me <- sum(subset[subset$metric==COMPARE_ME,]$count)
    nopred <- sum(subset[subset$metric==COMPARE_NOT_PREDICTED,]$count)
    
    percentageRow <- c(correct,amb,vme,me,nopred)
    
    ### columns X rows X number_of_possible_predictions
    #maxPredictions = PASCAL[[index]]*ROWS*(NUMBER_OF_ANTIBIOTICS-index)
    maxPredictions <- correct +amb +vme + me + nopred
    #sum(percentageRow)
    percentageRow <- percentageRow/maxPredictions
    #      print(paste(index,level,percentage,sep=" "))
    percentageFrame <- cbind(percentageFrame,percentageRow)
  }
  colnames(percentageFrame) <- range
  compare_class <- rownames(percentageFrame)
  percentageFrame <- cbind(compare_class,percentageFrame)
  if(is.na(level)){
    percentageFrame <- percentageFrame[rownames(percentageFrame) %in% c("correct","vme","me") ,]
  }
  percentageFrame
}

generate_statistics_for_index <- function(index = 6,antibiotic = NA,allStats = readStatisticsFrame("allstats",getStatisticsFolder(MODE)))
{
  #  range <- unique(allStats$noinputab)
  
  #  allSignis <- unique(allStats$significanslevel)
  #  signisRange <- allSignis
  
  #  signisRange <- c("01","005","0025")
  
  
  percentageFrame <- data.frame(row.names = c("correct","amb","vme","me","nopred"))
  subsetIndex <- allStats[allStats$noinputab==index,]
  subset <- subsetIndex[is.na(subsetIndex$significanslevel),]
  if(!is.na(antibiotic)){
    subset <- subset[subset$antibiotic==antibiotic,]
  }
  correct <- sum(subset[subset$metric==COMPARE_CORRECT,]$count)
  amb <- sum(subset[subset$metric==COMPARE_AMBIGUOUS,]$count)
  vme <- sum(subset[subset$metric==COMPARE_VME,]$count)
  me <- sum(subset[subset$metric==COMPARE_ME,]$count)
  nopred <- sum(subset[subset$metric==COMPARE_NOT_PREDICTED,]$count)
  
  percentageRow <- c(correct,amb,vme,me,nopred)
  # maxPredictions = PASCAL[[index]]*ROWS*(NUMBER_OF_ANTIBIOTICS-index)
  # if(!is.na(antibiotic)){
  #   maxPredictions <- maxPredictions/NUMBER_OF_ANTIBIOTICS
  # }
  #    sum(percentageRow)
  maxPredictions <- correct +amb +vme + me + nopred
  percentageRow <- percentageRow/maxPredictions
  
  percentageFrame <- cbind(percentageFrame,percentageRow)
  colnames(percentageFrame) <- "crude"
  compare_class <- rownames(percentageFrame)
  percentageFrame <- cbind(compare_class,percentageFrame)
  percentageFrame
}



generate_signi_statistics_for_index <- function(index = 6,antibiotic = NA, allStats = readStatisticsFrame("allstats",getStatisticsFolder(MODE)) )
{
  
  
  percentageFrame <- data.frame(row.names = c("correct","amb","vme","me","nopred"))
  signisRange <- c("01","005","0025")
  for(signi in signisRange) {
    percentageRow <- c()
    subsetIndex <- allStats[allStats$noinputab==index,]
    subset <- subsetIndex[!is.na(subsetIndex$significanslevel) & subsetIndex$significanslevel==fixSigni(signi),]
    if(!is.na(antibiotic)){
      subset <- subset[subset$antibiotic==antibiotic,]
    }
    correct <- sum(subset[subset$metric==COMPARE_CORRECT,]$count)
    amb <- sum(subset[subset$metric==COMPARE_AMBIGUOUS,]$count)
    vme <- sum(subset[subset$metric==COMPARE_VME,]$count)
    me <- sum(subset[subset$metric==COMPARE_ME,]$count)
    nopred <- sum(subset[subset$metric==COMPARE_NOT_PREDICTED,]$count)
    
    #all <- correct +amb +vme + me + nopred
    percentageRow <- c(correct,amb,vme,me,nopred)
    
    ### columns X rows X number_of_possible_predictions
    
    # OBSOLETE 
    # maxPredictions = PASCAL[[index]]*ROWS*(NUMBER_OF_ANTIBIOTICS-index)
    # if(!is.na(antibiotic)){
    #   maxPredictions <- maxPredictions/NUMBER_OF_ANTIBIOTICS
    # }
    maxPredictions <- correct +amb +vme + me + nopred
    #    sum(percentageRow)
    percentageRow <- percentageRow/maxPredictions
    #      print(paste(index,level,percentage,sep=" "))
    percentageFrame <- cbind(percentageFrame,percentageRow)
  }
  colnames(percentageFrame) <- unlist(lapply(signisRange,function(x){fixSigni(x)}))
  compare_class <- rownames(percentageFrame)
  percentageFrame <- cbind(compare_class,percentageFrame)
  percentageFrame
}


generate_ab_statistics <- function(metric = COMPARE_CORRECT)
{
  allStats <- readStatisticsFrame("allstats",getStatisticsFolder(MODE))
  
  range <- unique(allStats$noinputab)
  abs = unique(allStats$antibiotic)
  
  rows <- unique(allStats$antibiotic)
  
  abFrame <- data.frame(row.names = rows)
  
  for(index in range) {
    abRow <- c()
    for(ab in abs) {
      correct <- allStats[allStats$noinputab==index & allStats$metric==metric & is.na(allStats$significanslevel) & allStats$antibiotic==ab,]
      predicted <- allStats[allStats$noinputab==index & allStats$metric==COMPARE_PREDICTED & is.na(allStats$significanslevel) & allStats$antibiotic==ab ,]
      percentage <- sum(correct$count)/sum(predicted$count)
      abRow <- c(abRow,percentage)
    }
    abFrame <- cbind(abFrame,abRow)
  }
  colnames(abFrame) <- range
  antibiotic <- rownames(abFrame)
  abFrame <- cbind(antibiotic,abFrame)
  abFrame
}


# generate_ab_statistics_for_index <- function(index,allStats = readStatisticsFrame("allstats",getStatisticsFolder(MODE)))
# {
#   range <- unique(allStats$noinputab)
#   abs = unique(allStats$antibiotic)
#   
#   rows <- unique(allStats$antibiotic)
#   
#   abFrame <- data.frame(row.names = rows)
#   
#   metrics <- c(COMPARE_CORRECT,COMPARE_VME,COMPARE_ME)
#   for(metric in metrics) {
#     abRow <- c()
#     for(ab in abs) {
#       correct <- allStats[allStats$noinputab==index & allStats$metric==metric & is.na(allStats$significanslevel) & allStats$antibiotic==ab,]
#       predicted <- allStats[allStats$noinputab==index & allStats$metric==COMPARE_PREDICTED & is.na(allStats$significanslevel) & allStats$antibiotic==ab ,]
#       percentage <- sum(correct$count)/sum(predicted$count)
#       abRow <- c(abRow,percentage)
#     }
#     abFrame <- cbind(abFrame,abRow)
#   }
#   colnames(abFrame) <- metrics
#   antibiotic <- rownames(abFrame)
#   abFrame <- cbind(antibiotic,abFrame)
#   abFrame
# }

generate_ab_statistics_for_index <- function(index,allStats = readStatisticsFrame("allstats",getStatisticsFolder(MODE)),significanceLevel=NA)
{
  range <- unique(allStats$noinputab)
  abs = unique(allStats$antibiotic)
  
  rows <- unique(allStats$antibiotic)
  
  abFrame <- data.frame(row.names = rows)
  
  metrics <- c(COMPARE_CORRECT,COMPARE_VME,COMPARE_ME)
  for(metric in metrics) {
    abRow <- c()
    for(ab in abs) {
      if(is.na(significanceLevel)){
        correct <- allStats[allStats$noinputab==index & allStats$metric==metric & is.na(allStats$significanslevel) & allStats$antibiotic==ab,]
        predicted <- allStats[allStats$noinputab==index & allStats$metric==COMPARE_PREDICTED & is.na(allStats$significanslevel) & allStats$antibiotic==ab ,]
      }
      else {
        correct <- allStats[allStats$noinputab==index & allStats$metric==metric & !is.na(allStats$significanslevel) & fixSigni(significanceLevel)==allStats$significanslevel & allStats$antibiotic==ab,]
        predicted <- allStats[allStats$noinputab==index & allStats$metric %in% c(COMPARE_PREDICTED_OR_AMBIGUOUS,COMPARE_NOT_PREDICTED) & !is.na(allStats$significanslevel) & fixSigni(significanceLevel)==allStats$significanslevel & allStats$antibiotic==ab ,]
      }
      #      print(correct)
      percentage <- sum(correct$count)/sum(predicted$count)
      abRow <- c(abRow,percentage)
    }
    abFrame <- cbind(abFrame,abRow)
  }
  colnames(abFrame) <- metrics
  antibiotic <- rownames(abFrame)
  abFrame <- cbind(antibiotic,abFrame)
  abFrame
}



countWordsScalar <-function(scalar,split=" ")
{
  length(unlist(strsplit(scalar,split=split)))
}

countWordsPerColumnFrame <-function(aFrame,split=" ")
{
  lapply(aFrame,function(x) { sum(countWordsScalar(x,split))})
}

countWordsPerRowFrame <-function(aFrame,split=" ")
{
  apply(aFrame,1,function(x) { sum(countWordsScalar(x,split))})
}





countWordsFrame <-function(aFrame,split=" ")
{
  resultMatrix <- mapply(function(u){mapply(function(x){countWordsScalar(x,split)},u)},aFrame)
  resultFrame <- as.data.frame(resultMatrix)
  rownames(resultFrame) <- rownames(aFrame)
  resultFrame
}

#aFrame <- frames[["VME"]]

sieveWordsFrame <-function(aFrame,ab)
{
  aFunction <- function(x){
    rv <- ""
    if(length(grep(ab,x))>0){
      rv <- ab
    }
    rv}
  
  resultMatrix <- mapply(function(u){mapply(aFunction,u)},aFrame)
  resultFrame <- as.data.frame(resultMatrix)
  rownames(resultFrame) <- rownames(aFrame)
  resultFrame
}


#@deprecated
getCompareFrame <-function(comparetype,index,signi)
{
  if(is.na(signi)){
    predsFile <- makeShortFileName("preds",index)
  } else {
    predsFile <- makeShortFileName("confpreds",index,signi)
    
  }
  shortName <- paste(substring(predsFile,0,nchar(predsFile)-4),"_",comparetype,".csv",sep="")
  frame <- readOutputFrameShort(shortfile=shortName,folder=getCompareFolder(MODE))
  frame[is.na(frame)]<-""
  frame  
}

#@deprecated
getCounts <-function(comparetype,index,signi)
{
  frame <- getCompareFrame(comparetype,index,signi)
  counts <- countWordsPerColumnFrame(frame)
  counts
}


#deprecated
findBestCombinations<- function(signi=NA,fromBestCrude=FALSE)
{
  
  bestFrame <- data.frame()
  
  noinputab <- c()
  percentage <- c()
  combinations <- c()
  correct <- c()
  predictions <- c()
  maxpredictions <-c()
  fractionCorrect <- c()
  fractionPredictions <-c()
  for(index in range){
    
    correctCounts <- getCounts(COMPARE_CORRECT,index,signi)
    predsCounts <- getCounts(COMPARE_PREDICTED,index,signi)
    
    correctCountsForBest <- correctCounts
    predsCountsForBest <- predsCounts
    if(!is.null(signi) & fromBestCrude){
      correctCountsForBest <- getCounts(COMPARE_CORRECT,index,NA)
      predsCountsForBest <- getCounts(COMPARE_PREDICTED,index,NA)
    }
    
    # 2:  1188*   99*(14-2)
    # maxPerCol  <- maxPredictions(correctFrame,index)/ncol(correctFrame)
    
    ## First find best
    percentages <- as.double(correctCountsForBest)/as.double(predsCountsForBest)
    names(percentages) <- names(correctCountsForBest)
    bestNames <- names(percentages[percentages==max(percentages)])
    
    anotherPercentages <- as.double(correctCounts)/as.double(predsCounts)
    names(anotherPercentages)<-names(correctCounts)
    maxPerColumn <- ROWS * (NUMBER_OF_ANTIBIOTICS-index) 
    for (aBestName in bestNames) {
      aCorrect  <- as.integer(correctCounts[aBestName])
      anotherMaxP <- as.double(anotherPercentages[aBestName])
      aPrediction <- as.integer(predsCounts[aBestName])
      aCorrectFraction = as.double(correctCounts[aBestName])/maxPerColumn
      aPredictionFraction = as.double(predsCounts[aBestName])/maxPerColumn
      
      correct <- c(correct,aCorrect)
      predictions <- c(predictions,aPrediction)
      percentage <- c(percentage,anotherMaxP)
      combinations <- c(combinations,aBestName)
      maxpredictions <- c(maxpredictions,maxPerColumn)
      fractionCorrect <-c(fractionCorrect,aCorrectFraction)
      fractionPredictions <-c(fractionPredictions,aPredictionFraction)
      noinputab <- c(noinputab,index)
    }
  }
  bestFrame <- cbind(noinputab,as.character(percentage),combinations,as.character(correct),as.character(predictions),as.character(maxpredictions),as.character(fractionCorrect),as.character(fractionPredictions))
  
  colnames(bestFrame) <- c("noinputab","percentage","combinations","correct","predictions","maxpredictions","fraction_correct","fraction_predictions")
  
  bestFrame
}



GENERATE_SUB_STATISTICS <- function()
{
  technicalSigniStatistics <- generate_signi_statistics(TRUE)
  clinicalSigniStatistics <- generate_signi_statistics(FALSE)
  writeStatisticsFrame(technicalSigniStatistics,name = "technicalSigniStatistics",getStatisticsFolder(MODE))
  writeStatisticsFrame(clinicalSigniStatistics,name = "clinicalSigniStatistics",getStatisticsFolder(MODE))
  
  for(signi in c(NA,signis)){
    statistics <- generate_signi_statistics_details(signi)
    if(is.na(signi)){
      name <- paste("nonconformalStatisticsDetails")
    }
    else{
      name = paste("signiStatisticsDetails",signi,sep="-")
    }
    writeStatisticsFrame(statistics,name = name,getStatisticsFolder(MODE))
  }
  
  for(index in c(4,6,8)){
    statistics <- generate_signi_statistics_for_index(index)
    name = paste("signiStatisticsIndex",index,sep="-")
    writeStatisticsFrame(statistics,name = name,getStatisticsFolder(MODE))
    for(ab in ANTIBIOTICS){
      statistics <- generate_signi_statistics_for_index(index,ab)
      name = paste("signiStatisticsIndex",index,ab,sep="-")
      writeStatisticsFrame(statistics,name = name,getStatisticsFolder(MODE))
    }
  }
  
  for(index in c(4,6,8)){
    statistics <- generate_statistics_for_index(index)
    name = paste("statisticsIndex",index,sep="-")
    writeStatisticsFrame(statistics,name = name,getStatisticsFolder(MODE))
    
    for(ab in ANTIBIOTICS){
      statistics <- generate_statistics_for_index(index,ab)
      name = paste("statisticsIndex",index,ab,sep="-")
      writeStatisticsFrame(statistics,name = name,getStatisticsFolder(MODE))
    }
  }
  abStatistics <- generate_ab_statistics(metric = COMPARE_CORRECT)
  writeStatisticsFrame(abStatistics,name = "abStatistics-correct",getStatisticsFolder(MODE))
  
  abStatistics <- generate_ab_statistics(metric = COMPARE_VME)
  writeStatisticsFrame(abStatistics,name = "abStatistics-vme",getStatisticsFolder(MODE))
  
  abStatistics <- generate_ab_statistics(metric = COMPARE_ME)
  writeStatisticsFrame(abStatistics,name = "abStatistics-me",getStatisticsFolder(MODE))
  
  for(index in range){
    abStatistics <- generate_ab_statistics_for_index(index = index)
    writeStatisticsFrame(abStatistics,name = paste("abStatistics",index,sep="-"),getStatisticsFolder(MODE))
    for(signi in signis){
      abStatistics <- generate_ab_statistics_for_index(index = index,significanceLevel = signi)
      writeStatisticsFrame(abStatistics,name = paste("abStatistics",index,signi,sep="-"),getStatisticsFolder(MODE))
    }
  }
  
}


GENERATE_BEST_SUB_STATISTICS <- function()
{
  
  for (abs in BEST_ABS){
    #abs <- c ("AMP","CRO","CIP","TOB")
    word <- paste(abs,collapse="_")
    name <- paste("allstats",word,sep="-")
    print(name)
    allStats <- readStatisticsFrame(name,getStatisticsBestFolder(MODE))
    index <- length(abs)
    
    abStatistics <- generate_ab_statistics_for_index(index = index,allStats=allStats)
    writeStatisticsFrame(abStatistics,name = paste("abStatistics",word,sep="-"),getStatisticsBestFolder(MODE))
    
    for(signi in signis){
      abStatistics <- generate_ab_statistics_for_index(index = index,allStats=allStats,significanceLevel = signi)
      writeStatisticsFrame(abStatistics,name = paste("abStatistics",word,signi,sep="-"),getStatisticsBestFolder(MODE))
    }    
    
    statistics <- generate_statistics_for_index(index,allStats=allStats)
    name = paste("statisticsIndex",index,word,sep="-")
    writeStatisticsFrame(statistics,name = name,getStatisticsBestFolder(MODE))
    
    for(ab in ANTIBIOTICS){
      statistics <- generate_statistics_for_index(index,ab,allStats=allStats)
      name = paste("statisticsIndex",index,word,ab,sep="-")
      writeStatisticsFrame(statistics,name = name,getStatisticsBestFolder(MODE))
    }
    
    statistics <- generate_signi_statistics_for_index(index,allStats=allStats)
    name = paste("signiStatisticsIndex",index,word,sep="-")
    writeStatisticsFrame(statistics,name = name,getStatisticsBestFolder(MODE))
    for(ab in ANTIBIOTICS){
      statistics <- generate_signi_statistics_for_index(index,ab,allStats=allStats)
      name = paste("signiStatisticsIndex",index,word,ab,sep="-")
      writeStatisticsFrame(statistics,name = name,getStatisticsBestFolder(MODE))
    }
    
  }
  
}























GENERATE_SPECIFIC_STATISTICS <- function()
{
  generate_best_statistics()
  generate_sample_statistics()
  generate_ab_vs_metric("selected")
  generate_ab_vs_metric("best")
  
  generate_sample_vs_metric()
}



generate_best_statistics <- function()
{
  bestCombinationStatistics <- findBestCombinations()
  writeStatisticsFrame(bestCombinationStatistics,name = "bestStatistics",getStatisticsBestFolder(MODE))
  
  bestWords <- bestCombinationStatistics[,"combinations"]   
  dumpBestWordsFrame(bestWords,"bestWordFrame")
  for(signi in signis){
    bestCombinationStatistics <- findBestCombinations(signi = signi,fromBestCrude = FALSE)
    bestWords <- c(bestWords,bestCombinationStatistics[,"combinations"])
    writeStatisticsFrame(bestCombinationStatistics,name = paste("bestStatistics",signi,sep="_"),getStatisticsBestFolder(MODE))
    
    bestCombinationStatistics <- findBestCombinations(signi = signi,fromBestCrude = TRUE)
    writeStatisticsFrame(bestCombinationStatistics,name = paste("bestStatistics_frombestnonconformal",signi,sep="_"),getStatisticsBestFolder(MODE))
  }
  dumpBestWordsFrame(bestWords,"bestWordFrame_frombestnonconformal")
  
}

getComplementAntibiotics <-function(word)
{
  ANTIBIOTICS
  remainingAntibiotics <- lapply( ANTIBIOTICS, function(x){
    length(grep(x,word))>0
  }
  )
  ANTIBIOTICS[remainingAntibiotics!=TRUE]
}

generate_sample_vs_metric <-function()
{
  svm_range <- 4:8
  
  for (index in svm_range) {
    for (signi in c(NA,signis)){
      for(ab in c(NA,ANTIBIOTICS)){
        dump_sample_vs_metrics(index,signi,ab)
      }
    }
  }  
  for(index in c(6,8)){
    dump_sample_vs_metrics(index,NA,"AMC")
    dump_sample_vs_metrics(index,NA,"AMC","AMP",TRUE)
    dump_sample_vs_metrics(index,NA,"AMC","AMP",FALSE)
  }
}
#index <- 6
#signi <- NA
#ab<-"AMC"
#inputAb <- "AMP"
#inputAbpresent <- TRUE
#metric <- COMPARE_ME

#
#@deprecated
dump_sample_vs_metrics <- function(index,signi=NA,ab=NA,inputAb=NA,inputAbpresent = TRUE)
{
  if(is.na(signi)){
    metrics <- c(COMPARE_VME,COMPARE_ME,COMPARE_CORRECT)
  } else {
    metrics <- c(COMPARE_VME,COMPARE_ME,COMPARE_CORRECT,COMPARE_AMBIGUOUS,COMPARE_NOT_PREDICTED)
  }
  numberOfRows <- ROWS
  numberOfColumns <- length(metrics)
  share <- 1
  resultFrame <- data.frame(matrix(NA, nrow = numberOfRows, ncol = numberOfColumns))
  colnames(resultFrame) <- metrics
  for(metric in metrics) {
    compareFrame <- getCompareFrame(metric,index,signi)
    if(!is.na(ab)){
      compareFrame <- sieveWordsFrame(compareFrame,ab)
      matchingAb <- grepl(ab,colnames(compareFrame), fixed = TRUE)
      compareFrame <- compareFrame[,!matchingAb]
    }
    if(!is.na(inputAb)){
      cNames <- colnames(compareFrame)
      matching <- grepl(inputAb,cNames, fixed = TRUE)
      if(inputAbpresent){
        compareFrame <- compareFrame[,matching]
        share <- length(colnames(compareFrame))/length(cNames)
      } else {
        compareFrame <- compareFrame[,!matching]
        share <- length(colnames(compareFrame))/length(cNames)
      }
      #  compareFrame <- 
    }
    counts <- countWordsPerRowFrame(compareFrame)
    resultFrame[,metric] <- counts
    rownames(resultFrame) <- rownames(compareFrame)
  }
  
  if(is.na(ab)){
    maxPerRow <- PASCAL[[index]] * (NUMBER_OF_ANTIBIOTICS-index)
  } else {
    maxPerRow <- PASCAL[[index]] * (NUMBER_OF_ANTIBIOTICS-index)/NUMBER_OF_ANTIBIOTICS
  }
  apply(resultFrame,1,sum)
  maxPerRow = maxPerRow*share
  
  resultFrame <- resultFrame/maxPerRow
  resultFrame <- resultFrame[order(resultFrame$VME+resultFrame$ME,decreasing = TRUE),]
  resultFrame <- resultFrame[order(resultFrame$correct,decreasing = FALSE),]
  resultFrame <- resultFrame[order(resultFrame$VME,decreasing = TRUE),]
  
  base <- "samplemetrics"
  if(!is.na(ab)){
    base <- paste(base,ab,sep="-")
  }
  if(!is.na(inputAb)){
    if(inputAbpresent){
      base <- paste(base,inputAb,"given",sep="-")
    }
    else {
      base <- paste(base,inputAb,"notgiven",sep="-")
    }
  }  
  writeStatisticsFrame(resultFrame,name=paste(base,fixSigni(signi),index,sep="-"),folder = getStatisticsSampleMetricsFolder(MODE),row.names = TRUE)
  
}

generate_ab_vs_metric <-function(tag="selected")
{
  
  for(signi in c(NA,signis)) {
    metrics <- c(COMPARE_CORRECT,COMPARE_ME,COMPARE_VME,COMPARE_AMBIGUOUS)
    frames <- list(metrics)
    for(metric in metrics){
      name <- paste("samplewords",metric,tag,fixSigni(signi),"words",sep = "-")  ## FIXME use signi
      frame <- readStatisticsFrame(name,getStatisticsSampleWordFolder(MODE))
      frames[[metric]] <- frame
    }
    
    all <- colnames(frames[[COMPARE_CORRECT]])[2:ncol(frames[[COMPARE_CORRECT]])]
    
    for(word in all)  {
      #  word <- all[[5]]
      complement <- getComplementAntibiotics(word)
      numberOfRows <- length(complement)
      numberOfColumns <- length(metrics)
      resultFrame <- data.frame(matrix(NA, nrow = numberOfRows, ncol = numberOfColumns))
      row.names(resultFrame) <- complement
      colnames(resultFrame) <- metrics
      
      for (metric in metrics){
        aFrame <- frames[[metric]]
        for(ab in complement){
          sievedFrame <- sieveWordsFrame(aFrame,ab)
          countAbInFrame <- sum(sievedFrame[,word]==ab)
          resultFrame[ab,metric] <- countAbInFrame
        }
      }
      antibiotics <- row.names(resultFrame)
      resultFrame <- cbind(antibiotics,resultFrame)
      writeStatisticsFrame(resultFrame,paste("metrics",fixSigni(signi),word,sep="-"),getStatisticsAntibioticsMetricsFolder(MODE),row.names = FALSE)
    }
  }  
}


dumpBestWordsFrame <- function(bestWords,name)
{
  words <- unique(sort(bestWords))
  noinputab <- unlist(lapply(words, function(word){ length(unlist(strsplit(word,split = "_")))}))
  bestWordsFrame <- data.frame(noinputab,words)
  bestWordsFrame <- bestWordsFrame[order(noinputab),]
  writeStatisticsFrame(bestWordsFrame,name,getStatisticsBestFolder(MODE))  
}


listToWordsFrame <- function(sentences)
{
  aFrame <- data.frame(sentences)
  word <- sentences
  noinputab <- unlist(lapply(sentences,function(x){countWordsScalar(x,split="_")}) )
  data.frame(noinputab,word)
}


generate_sample_statistics <-function()
{
  
  bestWordsFrame <- readStatisticsFrame("bestWordFrame",getStatisticsBestFolder(MODE))
  for(signi in c(NA,signis)){
    abs_and_counts_best <- inspect_samples(bestWordsFrame,signi)
    dumpSampleWords(abs_and_counts_best,paste("best",fixSigni(signi),sep="-"))
  }
  if(NUMBER_OF_ANTIBIOTICS==14){  
    sentences <- c ("AMP_CRO_CIP_TOB","AMP_AMC_CRO_CIP_TOB", "AMP_AMC_CRO_CIP_OFX_TOB","AMC_PIP_TZP_CRO_CIP_MFX_GEN","AMC_PIP_TZP_CAZ_CRO_CIP_OFX_TOB")
  }
  else {
    sentences <- c ("AMP_CRO_CIP_TOB",
                    "AMP_CRO_OFX_LVX_TOB",
                    "AMP_CAZ_CRO_OFX_LVX_TOB",
                    "AMP_TZP_CAZ_CRO_OFX_LVX_TOB",
                    "AMP_TZP_CAZ_CRO_FEP_CIP_OFX_GEN")
  }
  selectedtWordsFrame <- listToWordsFrame(sentences)
  for(signi in c(NA,signis)){
    abs_and_counts_selected <- inspect_samples(selectedtWordsFrame,signi)
    dumpSampleWords(abs_and_counts_selected,paste("selected",fixSigni(signi),sep="-"))
  }
  
}




dumpSampleWords <- function(abs_and_counts,name){
  for(metric in COMPARE_METRICS_VECTOR){
    name_base <- paste("samplewords",metric,sep="-")
    wordsList <- abs_and_counts[[1]]
    metricWordsFrame <- wordsList[[metric]]
    writeStatisticsFrame(metricWordsFrame,paste(name_base,name,"words",sep="-"),getStatisticsSampleWordFolder(MODE),row.names = TRUE)
    
    countsList <- abs_and_counts[[2]]
    metricCountsFrame <- countsList[[metric]]
    writeStatisticsFrame(metricCountsFrame,paste(name_base,name,"counts",sep="-"),getStatisticsSampleWordFolder(MODE),row.names = TRUE)
  }
}

inspect_samples <- function(wordsFrame,signi=NA){
  allnoinputab  <- as.integer(unlist(unique(wordsFrame$noinputab)))
  countList <- list(COMPARE_METRICS_VECTOR)
  wordsList <- list(COMPARE_METRICS_VECTOR)
  noinputab <- allnoinputab[[1]]
  comparemetrics <- COMPARE_CORRECT
  for(comparemetrics in COMPARE_METRICS_VECTOR) {
    outputFrameWords <- NULL
    for(noinputab in allnoinputab){
      words <- wordsFrame[wordsFrame$noinputab==noinputab,]$word
      frame <- getCompareFrame(comparemetrics,noinputab,signi)
      selectedFrame <- frame[words]
      if(is.null(outputFrameWords)){
        outputFrameWords <- data.frame(row.names=rownames(selectedFrame))
      }
      outputFrameWords <- cbind(outputFrameWords,selectedFrame)
    }
    outputFrameCount <- countWordsFrame(outputFrameWords)
    
    item <- list(outputFrameWords)
    names(item)[1]<-comparemetrics
    wordsList[comparemetrics] <- item
    
    item <- list(outputFrameCount)
    names(item)[1]<-comparemetrics
    countList[comparemetrics] <- item
  }
  list(wordsList,countList)
} 


getStatisticsSampleFrame <- function(ab,index)
{
  #ab <- "AMC"
  #ab <- "AMP"
  #index <- 6
  base <- "samplemetrics"
  if(!is.na(ab)){
    base <- paste(base,ab,sep="-")
  }
  resultFrame <- readStatisticsFrame(name=paste(base,fixSigni(NA),index,sep="-"),folder = getStatisticsSampleMetricsFolder(MODE))
  resultFrame
}

dumpForHeatmap <-function()
{
  #  metric <- ME
  compares <- c(COMPARE_CORRECT, COMPARE_VME, COMPARE_ME)
  for(compare in compares){
    for(index in 4:8){
      #index <- 6
      #ab <- "AMC"
      #compare <- "ME"
      resultFrame <- NULL
      for(ab in ANTIBIOTICS){
        sf <- getStatisticsSampleFrame(ab,index)
        sf <- sf[order(as.numeric(sf$sample)),]
        rownames(sf) <-  sf$sample
        compareCol <- sf[,compare]
        if(is.null(resultFrame)){
          df <- as.data.frame(compareCol)
          rownames(df) <- sf$sample
          resultFrame <- df
        }
        else {
          resultFrame <- cbind(resultFrame,compareCol)
        }
        names(resultFrame)[ncol(resultFrame)] <- ab
      }
      base <- "percentagePredictions"
      writeStatisticsFrame(resultFrame,name=paste(base,compare,fixSigni(NA),index,sep="-"),folder = getStatisticsSampleMetricsFolder(MODE),row.names=TRUE)
    }
  }
}

MOST <-  function()
{
  stopifnot(dir.exists(getPredictionBase(MODE)))
  
  
  if(!dir.exists(getCompareFolder(MODE))){
    dir.create(getCompareFolder(MODE))
  }
  if(!dir.exists(getStatisticsFolder(MODE))){
    dir.create(getStatisticsFolder(MODE))
  }
  
  if(!dir.exists(getStatisticsBestFolder(MODE))){
    dir.create(getStatisticsBestFolder(MODE))
  }
  
  if(!dir.exists(getStatisticsSampleWordFolder(MODE))){
    dir.create(getStatisticsSampleWordFolder(MODE))
  }
  
  if(!dir.exists(getStatisticsMetricsFolder(MODE))){
    dir.create(getStatisticsMetricsFolder(MODE))
  }
  if(!dir.exists(getStatisticsSampleMetricsFolder(MODE))){
    dir.create(getStatisticsSampleMetricsFolder(MODE))
  }
  if(!dir.exists(getStatisticsAntibioticsMetricsFolder(MODE))){
    dir.create(getStatisticsAntibioticsMetricsFolder(MODE))
  }
  
  GENERATE_STATISTICS()
  GENERATE_SUB_STATISTICS()
  GENERATE_SPECIFIC_STATISTICS()
  
  for (abs in BEST_ABS){
    GENERATE_SUBSET_STATISTICS(abs)
  }
  GENERATE_BEST_SUB_STATISTICS()
  
}

#Allstats created
#
#@deprecated
GENERATE_COMPARES <- function()
{
  for(index in range){
    predsFiles <- makeShortFileName("preds",index)
    for(signi in signis){
      predsFiles <- c(predsFiles,list.files(getPredictionFolder(MODE),pattern = makeShortFileName("confpreds",index,signi)))
    }
    answerFile <-  makeShortFileName("answer",index)
    for(predsFile in predsFiles){
      predictionDataFrame <- readOutputFrameShort(short=predsFile,folder = getPredictionFolder(MODE))
      answerDataFrame <- readOutputFrameShort(short=answerFile,folder = getPredictionFolder(MODE))
      for ( name in names(COMPARE_FUNCTIONS)){
        f=COMPARE_FUNCTIONS[[name]]
        frame <- applyElementWise(x=answerDataFrame,y=predictionDataFrame,aFunction = f)
        newShortName <- paste(substring(predsFile,0,nchar(predsFile)-4),"_",name,".csv",sep="")
        writeOutputFrameShort(frame,shortfile=newShortName,folder=getCompareFolder(MODE))
      }
    }
  }
}



ALL <- function()
{
  stopifnot(dir.exists(getPredictionBase(MODE)))
  
  
  if(!dir.exists(getCompareFolder(MODE))){
    dir.create(getCompareFolder(MODE))
  }
  if(!dir.exists(getStatisticsFolder(MODE))){
    dir.create(getStatisticsFolder(MODE))
  }
  
  if(!dir.exists(getStatisticsBestFolder(MODE))){
    dir.create(getStatisticsBestFolder(MODE))
  }
  
  if(!dir.exists(getStatisticsSampleWordFolder(MODE))){
    dir.create(getStatisticsSampleWordFolder(MODE))
  }
  
  if(!dir.exists(getStatisticsMetricsFolder(MODE))){
    dir.create(getStatisticsMetricsFolder(MODE))
  }
  if(!dir.exists(getStatisticsSampleMetricsFolder(MODE))){
    dir.create(getStatisticsSampleMetricsFolder(MODE))
  }
  if(!dir.exists(getStatisticsAntibioticsMetricsFolder(MODE))){
    dir.create(getStatisticsAntibioticsMetricsFolder(MODE))
  }
  
  GENERATE_COMPARES()
  MOST()
}





