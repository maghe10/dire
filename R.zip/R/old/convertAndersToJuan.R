library(stats)
library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(purrr)
library(furrr)
library(future)

source(file='common.R')

INPUT_DIR <- paste(modelDirectory,"input",sep="/")
fileNameIn <- "sirAntibioticsModelWords_Mode-A.csv"
fileNameOut <- "input_Mode-A.csv"

readAndersFrame <- function(fileNameIn= "sirAntibioticsModelWords_Mode-A.csv")
{
  read.csv2(file=paste(INPUT_DIR,fileNameIn,sep = "/"))
  
}





# Convert patient information from the format in Anders implementation
# to the format in Juan implementation
#
# Example:
# Anders: SE 70 F 2014-10
# Juan: SE F 70 2014_10
#
# Operates on the x field
convertPatientID <-function(frame)
{
  convertedPatientID <- frame %>%
    separate(
      x,
      into = c("country", "age", "sex", "month"),
      sep = " ",
      remove = FALSE
    ) %>%
    mutate(
      age  = as.integer(age),
      month_mod = str_replace(month, "-", "_")  # "2022-09" → "2022_09"
    ) %>%
    mutate(
      month_mod = str_replace(month_mod, "_0", "_")  # "2022_09" → "2022_9"
    ) %>%
  #Remove when model is updated to include our dates. 
  mutate(
    month_mod = "2020_12"  # Last date juan handles
   ) %>%
   mutate(
      combined = paste(country, sex, age, month_mod, sep = " ")
    ) %>% select(combined)
  frame$x <- convertedPatientID$combined
  frame
}

# Convert anders frame to juan frame
#
# patient information from the format in Anders implementation
# to the format in Juan implementation
#
# Example:
# Anders: SE 70 F 2014-10
# Juan: SE F 70 2014_10
# 
# Anders:
# Antibiotic: comma separated list of all antibiotic
# x: patient information in anders format
#
#
convertFrame <- function(frame,inputAb)
{
  antibioticsSplit <- frame  %>%
    mutate(
      tokens = str_split(Antibiotic, ","),
      in_inputAb  = map(tokens, ~ .x[str_extract(.x, "^[A-Z]+") %in% inputAb]),
      not_inputAb = map(tokens, ~ .x[!(str_extract(.x, "^[A-Z]+") %in% inputAb)]),
      
      in_inputAb  = map_chr(in_inputAb,  ~ paste(.x, collapse = " ")),
      not_inputAb = map_chr(not_inputAb, ~ paste(.x, collapse = " "))
    ) %>% select(in_inputAb,not_inputAb)
  
  convertedPatientID <- frame %>%
    separate(
      x,
      into = c("country", "age", "sex", "month"),
      sep = " ",
      remove = FALSE
    ) %>%
    mutate(
      age  = as.integer(age),
      month_mod = str_replace(month, "-", "_")  # "2022-09" → "2022_09"
    ) %>%
    mutate(
      month_mod = str_replace(month_mod, "_0", "_")  # "2022_09" → "2022_9"
    )  %>%
    #Remove when model is updated to include our dates. 
    mutate(
      month_mod = "2020_12"  # Last date juan handles
    ) %>%
    mutate(
      combined = paste(country, sex, age, month_mod, sep = " ")
    ) %>% select(combined)
  
  
  anotherFrame <- data.frame(rep("ESCCOL",nrow(frame)),convertedPatientID,antibioticsSplit)
  colnames(anotherFrame) <- c("bacteria","patientdata","in_ab","out_ab")
  anotherFrame
}

#
# Convert the input file in Anders format to a similar, but with Juan patient information to be used in my python script that calls juans implementation.
# 
#
convertinputFrame <-function(name,mode)
{
  frame <- readAndersFrame(paste(name,"_",mode,".csv",sep=""))
  frame <- convertPatientID(frame)
  write.csv2(frame,paste(INPUT_DIR,paste(name,"Juan2020_12","_",mode,".csv",sep=""),sep = "/"),row.names = FALSE)
}

# Make an example that can be run with
# directly with juans inplementaton
#
CONVERTINPUTFRAMES <- function()
{
  convertinputFrame("sirAntibioticsModelWords","Mode-A")
  convertinputFrame("sirAntibioticsModelWords","Mode-B")
  convertinputFrame("sirAntibioticsModelWords","Mode-C")
}


CONVERTANDERSTOJUAN <- function()
{
  convertAndersJuanFrame("sirAntibioticsModelWords","Mode-A",parallel = TRUE)
  convertAndersJuanFrame("sirAntibioticsModelWords","Mode-B",parallel = TRUE)
  convertAndersJuanFrame("sirAntibioticsModelWords","Mode-C",parallel = TRUE)
}

# convertAndersJuanFrame <- function(name,mode)
# {
#   # name <- "sirAntibioticsModelWords"
#   # mode <- "Mode-A"
#   
# 
#   frame <- readAndersFrame(paste(name,"_",mode,".csv",sep=""))
#   for (i in 12:13){
#     #i <- 4
#     combinations <- colnames(read.csv2(file=paste(INPUT_DIR,paste("modelOutput",i,".csv",sep=""),sep = "/")))[-1]
#     frame2 <- tibble(text = combinations) %>%
#       mutate(parts = strsplit(text, "_")) 
#     for(aSample in frame$sample){
#       #aSample <- 1
#       row <- frame[aSample,]
#       frames_list <- lapply(seq_len(nrow(frame2)), function(i) {
#         convertFrame(row, frame2$parts[[i]])
#       })
#       juanFrame <- bind_rows(frames_list)
#       writeJuanFrame(frame = juanFrame,outputFile =  paste(name,"Juan","_",i,"_",aSample,".csv",sep=""),outputFolder = paste(INPUT_DIR,mode,sep="/"))
#     }
#   }
# }

convertAndersJuanFrame <- function(name, mode, indices = 4:13) {
  # name <- "sirAntibioticsModelWords"
  # mode <- "Mode-A"
  # indices <- 12:13   # which "k" values to convert
  
  # ------------------------------------------------------------------
  # 1) Read the Anders frame once
  # ------------------------------------------------------------------
  input_file <- sprintf("%s_%s.csv", name, mode)
  frame <- readAndersFrame(input_file)
  
  # Make sure 'sample' exists and is something we can split on
  if (!"sample" %in% names(frame)) {
    stop("convertAndersJuanFrame: 'frame' must have a 'sample' column.")
  }
  
  # Split once per sample so we don't repeatedly subset by row
  rows_by_sample <- split(frame, frame$sample)
  
  # Output directory for this mode
  out_dir_mode <- file.path(INPUT_DIR, mode)
  if (!dir.exists(out_dir_mode)) {
    dir.create(out_dir_mode, recursive = TRUE)
  }
  
  # ------------------------------------------------------------------
  # 2) Loop over all requested indices (e.g. 12, 13)
  # ------------------------------------------------------------------
  for (i in indices) {
    # --------------------------------------------------------------
    # 2a) Read combinations for this i only once
    # --------------------------------------------------------------
    model_output_file <- file.path(INPUT_DIR, sprintf("modelOutput%d.csv", i))
    
    # We only need the column names, so we can read minimal data
    combos_header <- read.csv2(file = model_output_file, nrows = 1)
    combinations  <- colnames(combos_header)[-1]   # drop first col (sample)
    
    # Pre-parse all combinations into parts once
    parts_list <- strsplit(combinations, "_", fixed = FALSE)
    
    # Optionally wrap into a tibble if you still want that structure:
    # frame2 <- tibble::tibble(text = combinations, parts = parts_list)
    
    message("Processing i = ", i, " with ", length(combinations), " combinations")
    
    # --------------------------------------------------------------
    # 2b) Loop over samples (using split list to avoid repeated subset)
    # --------------------------------------------------------------
    for (sample_id in names(rows_by_sample)) {
      row <- rows_by_sample[[sample_id]]  # 1-row data.frame / tibble
      
      # For each combination, convert once and collect
      frames_list <- lapply(parts_list, function(parts) {
        convertFrame(row, parts)
      })
      
      juanFrame <- dplyr::bind_rows(frames_list)
      
      # Build output file name safely
      out_file <- sprintf("%sJuan_%d_%s.csv", name, i, sample_id)
      print(out_file)
      print(out_dir_mode)
      writeJuanFrame(
        frame       = juanFrame,
        outputFile  = out_file,
        outputFolder = out_dir_mode
      )
    }
  }
  
  invisible(NULL)
}

convertAndersJuanFrame <- function(name,
                                   mode,
                                   indices  = 4:13,
                                   parallel = FALSE,
                                   workers  = NULL) {
  # name  <- "sirAntibioticsModelWords"
  # mode  <- "Mode-A"
  # indices <- 12:13
  # parallel <- TRUE/FALSE
  
  # ------------------------------------------------------------------
  # 1) Read the Anders frame once
  # ------------------------------------------------------------------
  input_file <- sprintf("%s_%s.csv", name, mode)
  frame <- readAndersFrame(input_file)
  
  if (!"sample" %in% names(frame)) {
    stop("convertAndersJuanFrame: 'frame' must have a 'sample' column.")
  }
  
  # Split once per sample so we don't repeatedly subset by row index
  rows_by_sample <- split(frame, frame$sample)  # named list: names = sample IDs
  
  # Output directory for this mode
  out_dir_mode <- file.path(INPUT_DIR, mode)
  if (!dir.exists(out_dir_mode)) {
    dir.create(out_dir_mode, recursive = TRUE)
  }
  
  # ------------------------------------------------------------------
  # 2) Optionally set up parallel plan
  # ------------------------------------------------------------------
  if (parallel) {
    # If workers not specified, use all available minus one
    if (is.null(workers)) {
      workers <- max(1L, future::availableCores() - 1L)
    }
    future::plan(future::multisession, workers = workers)
  }
  
  # ------------------------------------------------------------------
  # 3) Loop over all requested indices (e.g. 12, 13)
  # ------------------------------------------------------------------
  for (i in indices) {
    # --------------------------------------------------------------
    # 3a) Read combinations for this i only once
    # --------------------------------------------------------------
    model_output_file <- file.path(INPUT_DIR, sprintf("modelOutput%d.csv", i))
    
    # Read just header to get column names (faster)
    combos_header <- read.csv2(file = model_output_file, nrows = 1)
    combinations  <- colnames(combos_header)[-1]   # drop first col (sample)
    
    # Pre-parse all combinations into parts once
    parts_list <- strsplit(combinations, "_", fixed = FALSE)
    
    message("Processing i = ", i, " with ", length(combinations), " combinations")
    message("Number of samples: ", length(rows_by_sample))
    
    # --------------------------------------------------------------
    # 3b) Define per-sample worker function
    # --------------------------------------------------------------
    process_one_sample <- function(row_df, sample_id) {
      # row_df is a 1-row data frame for this sample
      # sample_id is the name from split() (character)
      
      frames_list <- lapply(parts_list, function(parts) {
        convertFrame(row_df, parts)
      })
      
      juanFrame <- dplyr::bind_rows(frames_list)
      
      out_file <- sprintf("%sJuan_%d_%s.csv", name, i, sample_id)
      
      writeJuanFrame(
        frame        = juanFrame,
        outputFile   = out_file,
        outputFolder = out_dir_mode
      )
      
      invisible(NULL)
    }
    
    # --------------------------------------------------------------
    # 3c) Either parallel or sequential over samples
    # --------------------------------------------------------------
    if (parallel) {
      # Parallel over samples with furrr
      furrr::future_walk2(
        .x        = rows_by_sample,
        .y        = names(rows_by_sample),
        .f        = process_one_sample,
        .progress = TRUE,
        .options  = furrr::furrr_options(seed = TRUE)
      )
    } else {
      # Sequential over samples with nice logging using purrr::iwalk
      purrr::iwalk(
        .x = rows_by_sample,
        .f = function(row_df, sample_id) {
          message("  Sample ", sample_id, " for i = ", i)
          process_one_sample(row_df, sample_id)
        }
      )
    }
  }
  
  invisible(NULL)
}



# Write a frame in the juan format, i.e. without row names and header.
# The columns, separated by comma are
#
# <species>,<patientid>, <input_ab, <output_ab>
#
# Example: 
# ESCCOL, HR F 70 2014_10, CRO_S AMX_R CIP_S GEN_S, CAZ_S AMP_S
#
writeJuanFrame <- function(frame,outputFile = fileNameOut,outputFolder = INPUT_DIR )
{
  if (!dir.exists(outputFolder)) {
    dir.create(outputFolder, recursive = TRUE)
  }
  
  
  write.table(frame,file=paste(outputFolder,outputFile,sep = "/"),
              sep = ",",
              col.names = FALSE,
              row.names = FALSE,
              quote = FALSE)
}

# Make an example in juan format based on my samples to be called
# directly with juans inplementaton
#
# It outputs a random selection of all combinations with 4 input antibiotics
CONVERT_EXAMPLE <- function()
{

  frame <- readAndersFrame()
  
  combinations <- colnames(read.csv2(file=paste(INPUT_DIR,"modelOutput4.csv",sep = "/")))[-1]
  combinations %>% stringr::str_split("_", simplify = TRUE) %>% as.vector()


  frame2 <- tibble(text = combinations) %>%
    mutate(parts = strsplit(text, "_")) 

  frames_list <- lapply(seq_len(nrow(frame2)), function(i) {
    convertFrame(frame, frame2$parts[[i]])
  })
  
  returnFrame <- bind_rows(frames_list)
  returnFrame <- returnFrame %>% slice_sample(n = 1000)


  WriteJuanFrame(returnFrame)
}