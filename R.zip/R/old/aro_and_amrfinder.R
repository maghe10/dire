library(httr)
library(ontologyIndex)
#install.packages("rdflib")
library(rdflib)

#install.packages("ontologyIndex")

# Example API endpoint for ARO
response <- GET("https://api.ebi.ac.uk/ena/aro/TEM-1")

# Parse the JSON response
aro_data <- content(response, "parsed")
