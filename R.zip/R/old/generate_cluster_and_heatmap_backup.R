library(stats)
library(readxl)
library(dplyr)
library(tibble)
library(pheatmap)
library(tidyverse) 
library(cluster)   
library(factoextra)
library(fpc)
library(gtable)
library(ggplot2)
library(grid)
library(gridExtra)
library(gridpattern)

source(file='common.R')
MODE <- "Mode-A"
source(file='model/modelcommon.R')


OUTPUT_DIR <- paste(processedRootR,"cluster",sep="/")
PDF_OUTPUT_DIR <- paste(OUTPUT_DIR,"pdf",sep="/")
TIFF_OUTPUT_DIR <- paste(OUTPUT_DIR,"tiff",sep="/")

FONTSIZE_COL <- 10

CLUSTER_LIST <- list()
PHEATMAP_LIST <- list()

allAntibioticsWithZonesInputColumns <- c("KISS I-F",	"KISS I-MEL","KISS I-CFR",	"KISS I-W",	"KISS I-CIP",	"KISS I-AMC",	"KISS II-CTX",	"KISS II-CAZ"	,"KISS II-MEM",	"KISS II-TOB",	"KISS II-TZP",	"KISS II-SXT",	
                                         "DDT-FOX","DDT-FEP", "Studie-1-AMP"	,"Studie-1-PRL",	"Studie-1-CN"	,"Studie-1-CRO",	"Studie-2-LEV","Studie-2-MFX",	"Studie-2-OFX",	"Studie-2-NA")
allAntibioticsWithZonesInputNames <- c("F",	"MEL","CFR",	"W",	"CIP",	"AMC",	"CTX",	"CAZ"	,"MEM",	"TOB",	"TZP",	"SXT",	
                                       "FOX","FEP", "AMP"	,"PIP",	"GEN"	,"CRO",	"LVX","MFX",	"OFX",	"NAL")


allAntibioticsInModel <- c("AMP",	"AMC","PRL","TZP", "CAZ","CRO",	"CTX"	,"FEP", "CIP","OFX"	,"LEV","MFX","CN", "TOB" )

allAntibioticsInModelModelNames <- c("AMP","AMC","PIP","TZP","CAZ","CRO","CTX","FEP","CIP","OFX","LVX","MFX","GEN","TOB")


allAntibioticsWithBreakpointNames <- c("F",	"MEL","CFR",	"W",	"CIP",	"AMC",	"CTX",	"CAZ"	,"MEM",	"TOB",	"TZP",	"SXT",	
                                       "FEP", "AMP"	,"PIP",	"GEN"	,"CRO",	"LVX","MFX",	"OFX")



allAntibioticsWithInvasiveSirInputColumns <- c("CIP",	"AMC",	"CTX",	"CAZ"	,"MEM",	"TOB",	"TZP",	"SXT",	
                                               "FEP", "AMP"	,"PRL",	"CN"	,"CRO",	"LEV","MFX",	"OFX")

allAntibioticsWithUTISirInputColumns <- c("F",	"MEL","CFR",	"W")



readESBL <- function()
{
  studieNummerColumn <- c("Studienummer")
  phenotypeExcel =  paste(processedRootExcel, "Tolkad_data.xlsx", sep="/")
  zoneMillisSheet <- read_xlsx(phenotypeExcel,sheet = 'MeasureIncluded')
  
  sirModel <- readSirAntibioticsModel()
  
  esblSubset <- as.data.frame(
    zoneMillisSheet  %>% select(c(studieNummerColumn,"DDT","AMPC","KISS II-MEM")))
  sirSubset <-   as.data.frame(sirModel %>% select(c("CAZ","CTX")))
  
  rownames(esblSubset) <- esblSubset[,1]
  esblSubset <- esblSubset[-1]
  
  #  oldESBL <- esblSubset$DDT!="n" | esblSubset$AMPC!="n"
  #  length(which(oldESBL))
  
  isM <- (esblSubset$AMPC=="p") & (sirModel$CTX=="R" | sirModel$CAZ=="R")
  isA <- (esblSubset$DDT=="p" & esblSubset$AMPC!="p") & (sirModel$CTX=="R" | sirModel$CAZ=="R")
  isCARBA <- (esblSubset$`KISS II-MEM`<25) & (sirModel$CTX=="R" | sirModel$CAZ=="R")
  
  # length(which(isM))
  # length(which(isA))
  # length(which(isCARBA))
  # length(which((sirModel$CTX=="R" | sirModel$CAZ=="R")))
  # length(which(esblSubset$AMPC=="p"))
  
  ESBL <- as.character(isA | isM | isCARBA)
  ESBL[ESBL=="FALSE"]="no"
  ESBL[isA]="A"
  ESBL[isM]="M"
  ESBL[isCARBA]="C"
  names(ESBL) <-rownames(esblSubset)
  
  ESBL  
}



readMillimetertable <- function()
{
  xxx <- read.csv2(paste(modelDirectory,"input","millimetertable.csv",sep="/"),check.names=FALSE)
  colnames(xxx)[-1] <- allAntibioticsWithZonesInputNames
  xxx
}

readPredictionsTable <- function(compare)
{
  #compare = "ME"
  base <- "percentagePredictions"
  xxx <- readStatisticsFrame(name=paste(base,compare,fixSigni(NA),6,sep="-"),folder=STATISTICS_SAMPLE_METRICS_FOLDER)
  xxx
}


# clusterOn  <- function(millimeterTable,centers) 
# {
#   df <- na.omit(millimeterTable)
#   df <- scale(df)
#   k <- kmeans(df, centers, nstart = 25)
#   k
# }


readSirAntibioticsModel <- function()
{
  phenotypeExcel =  paste(processedRootExcel, "Tolkad_data.xlsx", sep="/")
  zoneMillisSheet <- read_xlsx(phenotypeExcel,sheet = 'MeasureIncluded')
  sirSheetInvasiv <- read_xlsx(phenotypeExcel,sheet = 'Tolka Invasiv')
  # sirSheetUTI <- read_xlsx(phenotypeExcel,sheet = 'Tolka UTI')
  
  # sirAntibiotics <-  cbind(data.frame(sirSheetInvasiv[1:99,allAntibioticsWithInvasiveSirInputColumns]),
  #                          data.frame(sirSheetUTI[1:99,allAntibioticsWithUTISirInputColumns]))
  
  sirAntibioticsModel <- data.frame(sirSheetInvasiv[1:99,allAntibioticsInModel])
  colnames(sirAntibioticsModel) <- allAntibioticsInModelModelNames
  
  sirAntibioticsModel <- cbind(zoneMillisSheet$Studienummer,sirAntibioticsModel)
  colnames(sirAntibioticsModel)[1] <- "sample"
  
  sirAntibioticsModel
}


readATUAntibioticsModel <- function()
{
  phenotypeExcel =  paste(processedRootExcel, "Tolkad_data.xlsx", sep="/")
  zoneMillisSheet <- read_xlsx(phenotypeExcel,sheet = 'MeasureIncluded')
  atuSheet <- read_xlsx(phenotypeExcel,sheet = 'Tolka ATU')
  # sirSheetUTI <- read_xlsx(phenotypeExcel,sheet = 'Tolka UTI')
  
  # sirAntibiotics <-  cbind(data.frame(sirSheetInvasiv[1:99,allAntibioticsWithInvasiveSirInputColumns]),
  #                          data.frame(sirSheetUTI[1:99,allAntibioticsWithUTISirInputColumns]))
  
  atuSheetsModel <- data.frame(atuSheet[1:99,allAntibioticsInModel])
  
  atuSheetsModel[,] <- !is.na(atuSheetsModel) & atuSheetsModel=="Ja"
  
  colnames(atuSheetsModel) <- allAntibioticsInModelModelNames
  
  atuSheetsModel
}




greenYellowRed <- function()
{
  # Define the colors to transition between
  colors <- c("red", "yellow", "green")
  
  # Create a color ramp palette function
  color_ramp <- colorRampPalette(colors)
  
  # Generate a sequence of colors
  n <- 100  # Number of steps in the gradient
  gradient_colors <- color_ramp(n)
  gradient_colors
}

green <- function()
{
  # Define the colors to transition between
  colors <- c("white", "green")
  
  # Create a color ramp palette function
  color_ramp <- colorRampPalette(colors)
  
  # Generate a sequence of colors
  n <- 100  # Number of steps in the gradient
  gradient_colors <- color_ramp(n)
  gradient_colors
}

red <- function()
{
  # Define the colors to transition between
  colors <- c("white", "red")
  
  # Create a color ramp palette function
  color_ramp <- colorRampPalette(colors)
  
  # Generate a sequence of colors
  n <- 100  # Number of steps in the gradient
  gradient_colors <- color_ramp(n)
  gradient_colors
}

orange <- function()
{
  # Define the colors to transition between
  colors <- c("white", "orange")
  
  # Create a color ramp palette function
  color_ramp <- colorRampPalette(colors)
  
  # Generate a sequence of colors
  n <- 100  # Number of steps in the gradient
  gradient_colors <- color_ramp(n)
  gradient_colors
}





# # Load necessary libraries
# library(factoextra)
# 
# # Generate some example data
# set.seed(123)
# data <- matrix(rnorm(100), nrow = 10)
# 
# # Perform hierarchical clustering
# dist_matrix <- dist(data)  # Calculate distance matrix
# hc <- hclust(dist_matrix)  # Apply hierarchical clustering
# 
# # Cut the dendrogram into clusters (e.g., 3 clusters)
# clusters <- cutree(hc, k = 3)
# 
# # Visualize the clusters using fviz_cluster
# fviz_cluster(list(data = data, cluster = clusters))

clustersAndAnnotation <- function(dataFrame,numberOfClusters)
{
  #dataFrame <- tableToClusterOn
  #numberOfClusters <- 8
  
  data <- as.matrix(dataFrame)
  rownames(data) <- rownames(dataFrame)
  colnames(data) <- colnames(dataFrame)
  
  NO_CLUSTERS <- numberOfClusters
  
  # Perform hierarchical clustering
  dist_matrix <- dist(data)
  hc <- hclust(dist_matrix, method = "ward.D2")
  
  # FIXME make work   
  # ESBL_order = c("C", "M","A","no")
  # ESBL <- readESBL()
  # swap_order <- order(match(ESBL,ESBL_order))
  # hc2 <- hc
  # hc2$merge <- hc2$merge[swap_order,]
  # hc2$labels <- hc2$labels[swap_order]
  
  
  # Cut the dendrogram into clusters
  #  clusters <- cutree(hc2, k = NO_CLUSTERS)
  clusters <- cutree(hc, k = NO_CLUSTERS)
  
  # Create a data frame for annotation with correct factor levels
  annotation <- data.frame(Cluster = factor(clusters))
  rownames(annotation) <- rownames(data)
  
  # Ensure the levels of the Cluster factor match the keys in annotation_colors
  cluster_levels <- as.character(1:NO_CLUSTERS)
  annotation$Cluster <- factor(annotation$Cluster, levels = cluster_levels)
  
  # Define colors for each of the clusters
  annotation_colors <- list(Cluster = setNames(c("red", "blue", "green", "purple", "orange", "pink", "brown","cyan","yellow","gray")[1:NO_CLUSTERS], cluster_levels))
  list ("data"=data,"clusters" = clusters, "annotation" = annotation,"annotation_colors"=annotation_colors)
}

decorateWithESBL <- function(caa)
{
  annotation <- caa$annotation
  
  ESBL <- as.factor(readESBL())
  annotation <- cbind(annotation,ESBL)
  annotation_colors <- caa$annotation_colors
  annotation_colors <- list(Cluster = annotation_colors$Cluster,ESBL = setNames(c("yellow", "orange", "red","white"), c("A","M","C","no")))
  caa$annotation_colors <- annotation_colors
  caa$annotation <- annotation
  caa
}

decorateWithBushJacobiAMPAMC <- function(caa)
{
  aDir <- paste(processedRootR,assemblymethod,"amrfinder",sep="//")
  bushJacobi <- read.csv2(check.names = FALSE,file= paste(sep="",aDir, "\\" ,assemblymethod,"_bushJacobi_",amrfinderDatabase, ".csv"))
  
  annotation <- caa$annotation
  annotation_colors <- caa$annotation_colors
  
  SS_NAME <- "(none)"
  SR_NAME <- "2b"
  RR_NAME <- "1/2be/2br/2d/3"
  
  SS <- !(apply(bushJacobi[c("1","2b","2be","2br","2d","3")],1,any))
  RR <-  apply(bushJacobi[c("1","2be","2br","2d","3")],1,any)
  SR <- !(SS | RR)
  BushJacobi <- as.vector(SS)
  BushJacobi[which(SS)] <- SS_NAME
  BushJacobi[which(RR)] <- RR_NAME
  BushJacobi[which(SR)] <- SR_NAME
  BushJacobi <- as.factor(BushJacobi)
  
  whiteYellowRed <- setNames(c("white", "yellow","red"), c(SS_NAME,SR_NAME,RR_NAME))
  annotation <- cbind(annotation,BushJacobi)
  annotation_colors <- append(annotation_colors, list(whiteYellowRed))
  names(annotation_colors)[length(annotation_colors)]<- "BushJacobi"
  caa$annotation_colors <- annotation_colors
  caa$annotation <- annotation
  caa
}

decorateWithBushJacobi <- function(caa)
{
  aDir <- paste(processedRootR,assemblymethod,"amrfinder",sep="//")
  bushJacobi <- read.csv2(check.names = FALSE,file= paste(sep="",aDir, "\\" ,assemblymethod,"_bushJacobi_",amrfinderDatabase, ".csv"))
  
  annotation <- caa$annotation
  annotation_colors <- caa$annotation_colors
  
  blackAndWhite = setNames(c("white", "black"), c("TRUE","FALSE"))
  classes <- colnames(bushJacobi[-1])
  for(class in classes) {  
    #class <- "2be"
    classVector <- bushJacobi[[class]]
    names(classVector) <- bushJacobi[[1]]
    classFactor <- as.factor(classVector) 
    
    annotation <- cbind(annotation,classFactor)
    colnames(annotation)[ncol(annotation)] <- class
    
    annotation_colors <- append(annotation_colors, list(blackAndWhite))
    names(annotation_colors)[length(annotation_colors)]<- class
  }
  caa$annotation_colors <- annotation_colors
  caa$annotation <- annotation
  caa
}

exampleAnnotate <- function()
{
  # Load necessary libraries
  library(pheatmap)
  library(factoextra)
  
  # Generate some example data
  set.seed(123)
  data <- matrix(rnorm(100), nrow = 10)
  rownames(data) <- paste0("row_", seq(nrow(data)))
  colnames(data) <- paste0("row_", seq(ncol(data)))
  
  # Perform hierarchical clustering
  dist_matrix <- dist(data)
  hc <- hclust(dist_matrix,method = "ward.D2")
  
  # Cut the dendrogram into 7 clusters
  clusters <- cutree(hc, k = 7)
  
  # Create a data frame for annotation with correct factor levels
  annotation <- data.frame(Cluster = factor(clusters))
  rownames(annotation) <- rownames(data)
  
  # Ensure the levels of the Cluster factor match the keys in annotation_colors
  cluster_levels <- as.character(1:7)
  annotation$Cluster <- factor(annotation$Cluster, levels = cluster_levels)
  
  # Define colors for each of the 7 clusters
  annotation_colors <- list(Cluster = setNames(c("red", "blue", "green", "purple", "orange", "pink", "brown"), cluster_levels))
  
  # Create heatmap with annotation
  pheatmap(data, annotation_row = annotation, annotation_colors = annotation_colors)
  
}




rescaleMillimeters <- function(millimeterTableToRescale)
{
  colMax <- function (colData) {
    apply(colData, MARGIN=c(2), max)
  }
  colMin <- function (colData) {
    apply(colData, MARGIN=c(2), min)
  }
  
  abMax <- colMax(millimeterTableToRescale)
  abMin <- colMin(millimeterTableToRescale)
  
  returnValue <- millimeterTableToRescale
  
  for(col in 1:ncol(returnValue)){
    returnValue[,col] <-  (millimeterTableToRescale[,col]-abMin[col])/(abMax[col]-abMin[col])
  }
  returnValue
}




makeSirForHeatmap <- function(sirAntibiotics,modelMillimeterTable)
{
  sirToClusterOn <- sirAntibiotics[-1]
  sirToClusterOn[sirToClusterOn=="S"] <- 1
  sirToClusterOn[sirToClusterOn=="I"] <- 0.5
  sirToClusterOn[sirToClusterOn=="R"] <- 0
  
  # Make a table 
  
  for (row in 1:nrow(modelMillimeterTable)){
    for (col in 1:ncol(modelMillimeterTable)){
      modelMillimeterTable[row,col] = as.numeric(sirToClusterOn[row,col])
    }  
  }
  modelMillimeterTable
}

makeClusterPlot <- function(name,caa)
{
  # Visualize the clusters with fviz_cluster (which will perform PCA by default)
  p <- fviz_cluster(list(data = caa$data, cluster = caa$clusters),
                    palette = unlist(caa$annotation_colors$Cluster),
                    ellipse.type = "convex",  # Type of cluster ellipse
                    geom = "point",           # Point geometry
                    show.clust.cent = TRUE) + ggtitle(label='')  # Show cluster centers
  dumpFVizObject(name,p)
  p
}



fetchTables<- function(){
  millimeterTable <- readMillimetertable()
  rownames(millimeterTable) <- millimeterTable$sample
  modelMillimeterTable <- millimeterTable %>% select(allAntibioticsInModelModelNames)
  
  sirAntibiotics <-  readSirAntibioticsModel()
  
  sirTable <- makeSirForHeatmap(sirAntibiotics,modelMillimeterTable)
  rescaledMillimeters <- rescaleMillimeters(modelMillimeterTable) 
  millimetersTable <- modelMillimeterTable
  
  tablesList <- list (sirTable, rescaledMillimeters, millimetersTable )
  names(tablesList) <- c("SIR","RESCALEDMM","MM")
  tablesList
}

ESTIMATE_CLUSTERS <- function()
{
  tablesList <- fetchTables()
  for(tableName in names(tablesList) ){
    print(tableName)
    tableToClusterOn <- tablesList[[tableName]]
    estimateOptimalNumberofclusters(paste("estimate",tableName,sep = "_"),tableToClusterOn)
  }
}

fetchOptimalClusterSizeList <-function() {
  optimalClusterList <- list(10,8,4)
  names(optimalClusterList) <- c("SIR","RESCALEDMM","MM")
  optimalClusterList
}

PLOT_CLUSTERS <- function()
{
  tablesList <- fetchTables()
  for(tableName in names(tablesList) ){
    #tableName <- "RESCALEDMM"
    print(tableName)
    tableToClusterOn <- tablesList[[tableName]]
    numberOfClusters <- fetchOptimalClusterSizeList()[[tableName]]
    caa <- clustersAndAnnotation(tableToClusterOn,numberOfClusters) 
    caa <- decorateWithESBL(caa)
    makeClusterPlot(paste("cluster",tableName,numberOfClusters,sep = "_"),caa)  
  }
}


fetchPredictionsTable <- function(compare)
{
  table <- readPredictionsTable(compare)
  rownames(table) <- table$sample
  table %>% select(allAntibioticsInModelModelNames)
}




PHEATMAPS_AND_CLUSTERS_SELECTED <- function()
{
  tablesList <- fetchTables()
  primaryTableName <- "RESCALEDMM"
  tableToClusterOn <- tablesList[[primaryTableName]]
  numberOfClusters <- fetchOptimalClusterSizeList()[[primaryTableName]]
  caa <- clustersAndAnnotation(tableToClusterOn,numberOfClusters)
  #  caa <- decorateWithESBL(caa)
  #  caa <- decorateWithBushJacobiAMPAMC(caa)
  
  FONT_SIZE <- 3
  SHOW_NAMES <- FALSE
  COLOR <- greenYellowRed()
  ANNOTATION_ROW <- caa$annotation
  ANNOTATION_COLORS <- caa$annotation_colors
  LEGEND = FALSE
  CLUSTER_ROWS = TRUE
  CLUSTER_COLS = TRUE
  row_order <- NA
  col_order <- NA
  
  
  #Primary cluster and pheatmap as one picture in a grid  
  cpName <- paste("cluster",primaryTableName,numberOfClusters,sep = "_")
  cp <- makeClusterPlot(cpName,caa)  
  
  
  name <- paste("pheatmapWithCluster",primaryTableName,numberOfClusters,sep = "_")
  p <- pheatmap(tableToClusterOn,clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS, annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)
  row_order <- p$tree_row$order
  col_order <- p$tree_col$order 
  
  fviz_grob <- ggplotGrob(cp)
  # Add a frame to the fviz_cluster plot
  fviz_grob <- gtable_add_grob(
    fviz_grob,
    grobs = rectGrob(gp = gpar(col = "black", fill = NA, lwd = 2)),
    t = 1, l = 1, b = nrow(fviz_grob), r = ncol(fviz_grob)
  )
  
  heatmap_grob <- p$gtable
  
  # Add a frame to the heatmap
  heatmap_grob <- gtable_add_grob(
    heatmap_grob,
    grobs = rectGrob(gp = gpar(col = "black", fill = NA, lwd = 2)),
    t = 1, l = 1, b = nrow(heatmap_grob), r = ncol(heatmap_grob)
  )
  aGrid <- grid.arrange(fviz_grob, heatmap_grob, ncol = 2, widths = c(280,200),heights = c(480))
  dumpGridObject(name="ClusterAndHeatmap",aGrid)
  
  
  #From now on we skip clustering as row_order and col_orders are fixed
  CLUSTER_ROWS = FALSE
  CLUSTER_COLS = FALSE
  # VME and MEs as one picture in a grid
  caa <- decorateWithBushJacobiAMPAMC(caa)
  ANNOTATION_ROW <- caa$annotation
  ANNOTATION_COLORS <- caa$annotation_colors
  
  
  predictions <- fetchPredictionsTable("VME")
  COLOR <-  red()
  vmePheatmap <- pheatmap(predictions[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW,annotation_legend=FALSE, annotation_colors =  ANNOTATION_COLORS,legend=FALSE,main = "")
  
  predictions <- fetchPredictionsTable("ME")
  COLOR <-  orange()
  mePheatmap <- pheatmap(predictions[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_legend=FALSE,annotation_colors =  ANNOTATION_COLORS,legend=FALSE,main = "")
  
  sirTable <- tablesList[["SIR"]]
  atuTable <- readATUAntibioticsModel()
  display_numbers <- matrix(ifelse(as.matrix(atuTable), "\u2217", ""), nrow(atuTable))
  
  COLOR <- greenYellowRed()
  #  sirPheatmap <- pheatmap(sirTable[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=FALSE,main = "")
  sirPheatmap <- pheatmap(sirTable[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=FALSE,main = "", 
                          display_numbers = display_numbers[row_order,col_order],fontsize_number = 8)
  
  add_grob <- function(heatmap){
    gtable_add_grob(
      heatmap$gtable,
      grobs = rectGrob(gp = gpar(col = "black", fill = NA, lwd = 2)),
      t = 1, l = 1, b = nrow(heatmap_grob), r = ncol(heatmap_grob)
    )
  }
  vmePheatmapGrob <- add_grob(vmePheatmap)
  mePheatmapGrob <- add_grob(mePheatmap)
  sirPheatmapGrob <- add_grob(sirPheatmap)
  aGrid <- grid.arrange(vmePheatmapGrob,mePheatmapGrob,sirPheatmapGrob, ncol = 3, widths = c(200,200,280),heights = c(480))
  
  dumpGridObject(name="HeatmapErrorSIR",aGrid)
  
  
}

PHEATMAPS <- function()
{
  tablesList <- fetchTables()
  for(tableName in names(tablesList) ){
    for(tableName in names(tablesList) ){
      print(tableName)
      tableToClusterOn <- tablesList[[tableName]]
      numberOfClusters <- fetchOptimalClusterSizeList()[[tableName]]
      caa <- clustersAndAnnotation(tableToClusterOn,numberOfClusters) 
      caa <- decorateWithESBL(caa)
      
      FONT_SIZE <- 3
      SHOW_NAMES <- FALSE
      COLOR <- greenYellowRed()
      ANNOTATION_ROW <- caa$annotation
      ANNOTATION_COLORS <- caa$annotation_colors
      LEGEND = FALSE
      CLUSTER_ROWS = TRUE
      CLUSTER_COLS = TRUE
      row_order <- NA
      col_order <- NA
      
      
      makeClusterPlot(paste("cluster",tableName,numberOfClusters,sep = "_"),caa)  
      name <- paste("pheatmapWithCluster",tableName,numberOfClusters,sep = "_")
      dumpPheatmapObject(name,
                         function (colData) {
                           p <- pheatmap(tableToClusterOn,clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS, annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)
                           PHEATMAP_LIST[[name]] <- p
                           # assign in outer scope using <<- operator
                           row_order <<- p$tree_row$order
                           col_order <<- p$tree_col$order 
                         } 
      )
      name <- paste("pheatmapWithClusterThin",tableName,numberOfClusters,sep = "_")
      dumpPheatmapObject(name,
                         function (colData) {
                           p <- pheatmap(tableToClusterOn,clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS, annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)
                           PHEATMAP_LIST[[name]] <- p
                           # assign in outer scope using <<- operator
                           row_order <<- p$tree_row$order
                           col_order <<- p$tree_col$order
                         }, width=300,height=480,
      )
      
      CLUSTER_ROWS = FALSE
      CLUSTER_COLS = FALSE
      for(innerTableName in names(tablesList) ){
        innerTable <- tablesList[[innerTableName]]
        
        name <- paste("pheatmap",innerTableName, "clustererOn",tableName,numberOfClusters,sep = "_")
        dumpPheatmapObject(name,
                           function (colData) {
                             ##                           pheatmap(innerTable[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)                           
                             p <- pheatmap(innerTable[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)
                             PHEATMAP_LIST[[name]] <- p
                           }                            
        )
      }
      
      sirTable <- tablesList[["SIR"]]
      name <- paste("pheatmap","SIRThin", "clustererOn",tableName,numberOfClusters,sep = "_")
      dumpPheatmapObject(name,
                         function (colData) {
                           p <- pheatmap(sirTable[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)
                           PHEATMAP_LIST[[name]] <- p
                         },width=240,height=480                          
      )                 
      COMPARE_CORRECT <- "correct"
      COMPARE_VME <- "VME"
      COMPARE_ME <- "ME"
      compares <- c(COMPARE_CORRECT, COMPARE_VME, COMPARE_ME)
      colorsCompares <- list(green(),red(),orange())
      
      
      for(i in 1:3){
        compare <- compares[[i]]
        predictions <- fetchPredictionsTable(compare)
        color <- colorsCompares[[i]]
        COLOR = color
        name <- paste("pheatmap",compare,"clustererOn",tableName,numberOfClusters,sep = "_")
        dumpPheatmapObject(paste("pheatmap",compare,"clustererOn",tableName,numberOfClusters,sep = "_"),
                           function (colData) {
                             p<- pheatmap(predictions[row_order,col_order],clustering_method = "ward.D2",fontsize_row = FONT_SIZE,fontsize_col = FONTSIZE_COL,show_rownames = SHOW_NAMES,color=COLOR,cluster_rows = CLUSTER_ROWS,cluster_cols = CLUSTER_COLS,annotation_row = ANNOTATION_ROW, annotation_colors =  ANNOTATION_COLORS,legend=LEGEND)
                             PHEATMAP_LIST[[name]] <- p 
                           },width=240,height=480
        )
      }
    }
  }
}




ALL  <- function()
{
  
  if(!dir.exists(PDF_OUTPUT_DIR)){
    dir.create(PDF_OUTPUT_DIR)
  }
  if(!dir.exists(TIFF_OUTPUT_DIR)){
    dir.create(TIFF_OUTPUT_DIR)
  }
  ESTIMATE_CLUSTERS()
  PHEATMAPS_AND_CLUSTERS_SELECTED()
  
  PLOT_CLUSTERS()
  PHEATMAPS()
}



dumpGridObject<-function(name,p,...){
  
  ggsave(filename = paste(PDF_OUTPUT_DIR,paste(name,"pdf",sep="."),sep="/"),plot=p)
  ggsave(filename = paste(TIFF_OUTPUT_DIR,paste(name,"tiff",sep="."),sep="/"),plot=p)
  
  # pdf(paste(PDF_OUTPUT_DIR,paste(name,"pdf",sep="."),sep="/"))
  # p()
  # dev.off()
  # tiff(paste(TIFF_OUTPUT_DIR,paste(name,"tiff",sep="."),sep="/"),...)
  # p()
  # dev.off()
  # jpeg(paste(OUTPUT_DIR,paste(name,"jpg",sep="."),sep="/"))
  # p()
  # dev.off()
  # png(paste(OUTPUT_DIR,paste(name,"png",sep="."),sep="/"))
  # p()
  # dev.off()
  # postscript(paste(OUTPUT_DIR,paste(name,"eps",sep="."),sep="/"))
  # p()
  # dev.off()
  p
}



dumpPheatmapObject<-function(name,p,...){
  pdf(paste(PDF_OUTPUT_DIR,paste(name,"pdf",sep="."),sep="/"))
  p()
  dev.off()
  tiff(paste(TIFF_OUTPUT_DIR,paste(name,"tiff",sep="."),sep="/"),...)
  p()
  dev.off()
  # jpeg(paste(OUTPUT_DIR,paste(name,"jpg",sep="."),sep="/"))
  # p()
  # dev.off()
  # png(paste(OUTPUT_DIR,paste(name,"png",sep="."),sep="/"))
  # p()
  # dev.off()
  # postscript(paste(OUTPUT_DIR,paste(name,"eps",sep="."),sep="/"))
  # p()
  # dev.off()
  p
}


dumpFVizObject <-function(name,p,...){
  pdf(paste(PDF_OUTPUT_DIR,paste(name,"pdf",sep="."),sep="/"))
  plot(p)
  dev.off()
  tiff(paste(TIFF_OUTPUT_DIR,paste(name,"tiff",sep="."),sep="/"),...)
  plot(p)
  dev.off()
  # jpeg(paste(OUTPUT_DIR,paste(name,"jpg",sep="."),sep="/"))
  # plot(p)
  # dev.off()
  # png(paste(OUTPUT_DIR,paste(name,"png",sep="."),sep="/"))
  # plot(p)
  # dev.off()
  # postscript(paste(OUTPUT_DIR,paste(name,"eps",sep="."),sep="/"))
  # plot(p)
  # dev.off()
}

estimateOptimalNumberofclusters <- function(name , dataMatrix)
{
  paste("gap",name,sep = "_")
  
  df <- scale(dataMatrix)
  df <- dataMatrix
  
  # Elbow method
  p = fviz_nbclust(df, hcut, method = "wss",hc_method = "ward.D2") +
    labs(subtitle = "Elbow method")
  dumpFVizObject(paste("wss",name,sep = "_"),p)
  
  # Silhouette method
  p = fviz_nbclust(df, hcut, method = "silhouette",hc_method = "ward.D2")+
    labs(subtitle = "Silhouette method")
  dumpFVizObject(paste("silhouette",name,sep = "_"),p)
  
  # Gap statistic
  # nboot = 50 to keep the function speedy. 
  # recommended value: nboot= 500 for your analysis.
  # Use verbose = FALSE to hide computing progression.
  set.seed(123)
  p = fviz_nbclust(df, hcut, nstart = 25,  method = "gap_stat", nboot = 50,hc_method = "ward.D2")+
    labs(subtitle = "Gap statistic method")
  dumpFVizObject(paste("gap_stat",name,sep = "_"),p)
  
  # Gap statistic
  set.seed(123)
  gap_stat <- clusGap(df, FUN = hcut, nstart = 25,
                      K.max = 10, B = 10)
  print(gap_stat, method = "firstmax")
  
  p = fviz_gap_stat(gap_stat)
  dumpFVizObject(paste("gap_stat_clusGap",name,sep = "_"),p)
  
}


