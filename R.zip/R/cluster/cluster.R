library(dplyr)
library(readr)
library(tidyr)
library(pheatmap)
library(factoextra)
library(ggplot2)
library(patchwork)
source("common.R")
source("genotype/genotypeCommon.R")
source("manuscript/generic_plot_helpers.R")
# ============================================================
# Configuration
# ============================================================

MODEL_ANTIBIOTICS <- ANTIBIOTICS
BETA_LACTAMS <- c("AMP", "AMC", "PIP", "TZP", "CAZ", "CRO", "CTX", "FEP")

cluster_palette <- function(n) {
  base <- c("blue", "green", "purple",
            "pink", "brown", "cyan","black")
  setNames(base[seq_len(n)], as.character(seq_len(n)))
}

# lower rank = placed higher up
ESBL_PRIORITY <- c(
  "C"   = 1,
  "A+M" = 2,
  "M"   = 3,
  "A"   = 4,
  "no"  = 5
)



gradient_red <- function(n = 100) colorRampPalette(c("white", "red"))(n)
gradient_orange <- function(n = 100) colorRampPalette(c("white", "orange"))(n)
gradient_green_yellow_red <- function(n = 100) colorRampPalette(c("red", "yellow", "green"))(n)

# ============================================================
# IO
# ============================================================

read_semicolon_csv <- function(path) {
  read.csv2(path, check.names = FALSE, stringsAsFactors = FALSE)
}

load_cluster_data <- function(data_dir = ".") {
  list(
    atu                  = read_semicolon_csv(file.path(data_dir, "atu.csv")),
    breakpoints          = read_semicolon_csv(file.path(data_dir, "breakpoints.csv")),
    demographics         = read_semicolon_csv(file.path(data_dir, "demographicstable.csv")),
    esbl                 = read_semicolon_csv(file.path(data_dir, "esbl.csv")),
    mm_full              = read_semicolon_csv(file.path(data_dir, "millimetertable.csv")),
    mm_model             = read_semicolon_csv(file.path(data_dir, "modelmillimetertable.csv")),
    mm_full_rescaled     = read_semicolon_csv(file.path(data_dir, "millimetertableRescaled.csv")),
    mm_model_rescaled    = read_semicolon_csv(file.path(data_dir, "modelmillimetertableRescaled.csv")),
    sir                  = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel.csv")),
    sir_mode_a           = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-A.csv")),
    sir_mode_b           = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-B.csv")),
    sir_mode_c           = read_semicolon_csv(file.path(data_dir, "sirAntibioticsModel_Mode-C.csv"))
  )
}

# ============================================================
# Small utilities
# ============================================================

as_sample_rownames <- function(df) {
  stopifnot("sample" %in% colnames(df))
  rn <- df$sample
  df <- as.data.frame(df)
  rownames(df) <- rn
  df
}

select_model_antibiotics <- function(df) {
  df %>%
    as.data.frame() %>%
    select(sample, all_of(MODEL_ANTIBIOTICS))
}

drop_sample_column <- function(df) {
  df %>% select(-sample)
}

safe_rescale_01 <- function(df_numeric) {
  out <- df_numeric
  for (j in seq_len(ncol(out))) {
    x <- out[[j]]
    rng <- range(x, na.rm = TRUE)
    if (is.infinite(rng[1]) || is.infinite(rng[2]) || isTRUE(all.equal(rng[1], rng[2]))) {
      out[[j]] <- 0
    } else {
      out[[j]] <- (x - rng[1]) / (rng[2] - rng[1])
    }
  }
  out
}

sir_to_numeric <- function(sir_df) {
  out <- sir_df
  out[out == "S"] <- 1
  out[out == "I"] <- 0.5
  out[out == "R"] <- 0
  out[] <- lapply(out, as.numeric)
  out
}

wrap_pheatmap <- function(ph) {
  patchwork::wrap_elements(full = ph$gtable, clip = FALSE)
}

panel_box_theme <- theme(
  plot.background = element_rect(fill = NA, colour = NA),
  plot.margin = margin(4, 4, 4, 4)
)

# ============================================================
# Data extractors
# ============================================================

read_millimeter_table <- function(dat) {
  dat$mm_model %>%
    select_model_antibiotics() %>%
    as_sample_rownames()
}

read_rescaled_millimeter_table <- function(dat, use_existing = TRUE) {
  if (use_existing) {
    dat$mm_model_rescaled %>%
      select_model_antibiotics() %>%
      as_sample_rownames()
  } else {
    mm <- read_millimeter_table(dat)
    mm_only <- drop_sample_column(mm)
    mm_scaled <- safe_rescale_01(mm_only)
    out <- cbind(sample = rownames(mm), mm_scaled)
    as_sample_rownames(out)
  }
}

read_sir_antibiotics_model <- function(dat, mode = NA) {
  sir_tbl <- if (is.na(mode)) {
    dat$sir
  } else {
    switch(
      mode,
      "Mode-A" = dat$sir_mode_a,
      "Mode-B" = dat$sir_mode_b,
      "Mode-C" = dat$sir_mode_c,
      stop("Unknown mode: ", mode)
    )
  }
  
  sir_tbl %>%
    select_model_antibiotics() %>%
    as_sample_rownames()
}

read_atu_antibiotics_model <- function(dat) {
  dat$atu %>%
    select_model_antibiotics() %>%
    as_sample_rownames()
}

read_esbl_annotation <- function(dat) {
  esbl <- dat$esbl %>%
    mutate(
      ESBL = case_when(
        ESBL_CARBA ~ "C",
        ESBL_A & ESBL_M ~ "A+M",
        ESBL_M ~ "M",
        ESBL_A ~ "A",
        TRUE ~ "no"
      )
    ) %>%
    select(sample, ESBL)
  
  rownames(esbl) <- esbl$sample
  esbl$sample <- NULL
  esbl
}

fetch_tables <- function(dat, use_existing_rescaled = TRUE) {
  mm <- read_millimeter_table(dat)
  mm_rescaled <- read_rescaled_millimeter_table(dat, use_existing = use_existing_rescaled)
  sir <- read_sir_antibiotics_model(dat)
  sir_num <- sir_to_numeric(drop_sample_column(sir))
  
  list(
    SIR = sir_num,
    RESCALEDMM = drop_sample_column(mm_rescaled),
    MM = drop_sample_column(mm)
  )
}

# ============================================================
# Clustering + annotations
# ============================================================
order_rows_by_cluster_esbl_resistance <- function(
    caa,
    mat,
    cluster_order = NULL,
    esbl_priority = c("C" = 1, "A+M" = 2, "M" = 3, "A" = 4, "no" = 5)
) {
  stopifnot(all(rownames(caa$annotation) %in% rownames(mat)))
  
  ann <- caa$annotation
  mat <- mat[rownames(ann), , drop = FALSE]
  
  # lower mean == more resistant
  isolate_mean <- rowMeans(mat, na.rm = TRUE)
  
  # original tree order as final tie-breaker
  order_names <- rownames(caa$data)[caa$hc$order]
  rank <- match(rownames(ann), order_names)
  
  ann2 <- ann %>%
    mutate(
      sample = rownames(.),
      .cluster = as.character(Cluster),
      .esbl = as.character(ESBL),
      .esbl_rank = unname(esbl_priority[.esbl]),
      .isolate_mean = isolate_mean,
      .rank = rank
    )
  
  # fallback for unknown ESBL labels
  ann2$.esbl_rank[is.na(ann2$.esbl_rank)] <- max(esbl_priority, na.rm = TRUE) + 1
  
  # if cluster order not supplied, keep numeric/alphabetic cluster order
  if (is.null(cluster_order)) {
    cl <- unique(ann2$.cluster)
    suppressWarnings(cl_num <- as.numeric(cl))
    if (all(!is.na(cl_num))) {
      cluster_order <- as.character(sort(cl_num))
    } else {
      cluster_order <- sort(cl)
    }
  } else {
    cluster_order <- as.character(cluster_order)
  }
  
  # any clusters not listed go last
  missing_clusters <- setdiff(unique(ann2$.cluster), cluster_order)
  cluster_order <- c(cluster_order, sort(missing_clusters))
  
  cluster_rank <- setNames(seq_along(cluster_order), cluster_order)
  ann2$.cluster_rank <- unname(cluster_rank[ann2$.cluster])
  
  ann2 <- ann2 %>%
    arrange(
      .cluster_rank,       # user-defined cluster order
      .esbl_rank,          # C first within cluster
      .isolate_mean,    # lowest mm first within ESBL
      .rank                # tie-breaker
    )
  
  ann2$sample
}
  

renumber_clusters_by_order <- function(caa, cluster_order) {
  ann <- caa$annotation
  
  cluster_order <- as.character(cluster_order)
  current_clusters <- as.character(unique(ann$Cluster))
  
  # add any missing clusters at the end
  missing <- setdiff(current_clusters, cluster_order)
  cluster_order <- c(cluster_order, sort(missing))
  
  # mapping old → new labels
  new_labels <- seq_along(cluster_order)
  names(new_labels) <- cluster_order
  
  ann$Cluster <- factor(
    new_labels[as.character(ann$Cluster)],
    levels = seq_along(cluster_order)
  )
  
  caa$annotation <- ann
  caa$clusters <- as.integer(as.character(ann$Cluster))
  
  # update colors to match new numbering
  caa$annotation_colors$Cluster <- cluster_palette(length(cluster_order))
  
  caa
}


clusters_and_annotation_umap <- function(data_frame, k) {
  data_mat <- as.matrix(data_frame)
  print(head(data_frame))
  set.seed(123)
  um <- uwot::umap(
    data_mat,
    n_components = 2
  )
  rownames(um) <- rownames(data_mat)
  
  hc_umap <- hclust(dist(um), method = "ward.D2")
  clusters_umap <- cutree(hc_umap, k = k)
  
  annotation <- data.frame(
    Cluster = factor(as.character(clusters_umap), levels = as.character(seq_len(k))),
    row.names = rownames(data_frame)
  )
  
  annotation_colors <- list(
    Cluster = cluster_palette(k)
  )
  
  list(
    data = data_mat,
    umap = um,
    hc = hc_umap,
    clusters = clusters_umap,
    annotation = annotation,
    annotation_colors = annotation_colors
  )
}



clusters_and_annotation_pca <- function(data_frame, k) {
  data_mat <- as.matrix(data_frame)

  hc <- hclust(dist(data_mat), method = "ward.D2")
  clusters <- cutree(hc, k = k)

  annotation <- data.frame(
    Cluster = factor(clusters, levels = as.character(seq_len(k))),
    row.names = rownames(data_frame)
  )

  annotation_colors <- list(
    Cluster = cluster_palette(k)
  )

  list(
    data = data_mat,
    hc = hc,
    clusters = clusters,
    annotation = annotation,
    annotation_colors = annotation_colors
  )
}

clusters_and_annotation <- function(data_frame, k) {
  clusters_and_annotation_pca(data_frame, k)
}



decorate_with_esbl <- function(caa, dat) {
  esbl <- read_esbl_annotation(dat)
  
  esbl <- esbl[rownames(caa$annotation), , drop = FALSE]
  caa$annotation$ESBL <- factor(esbl$ESBL, levels = c("A", "M","A+M","C", "no"))
  
  caa$annotation_colors$ESBL <- c(
    "C" = "darkred",
    "A+M" = "red",
    "M" = "orange",
    "A" = "yellow",
    "no" = "white"
  )
  caa
}



decorate_with_quinolone_family_presence <- function(caa, genotypeGroupTable) {
  
  qf <- genotypeGroupTable %>%
    dplyr::select(sample, Quinolone_families) %>%
    dplyr::mutate(
      sample = as.character(sample),
      Quinolone_families = dplyr::if_else(
        is.na(Quinolone_families), "", Quinolone_families
      )
    )
  
  rownames(qf) <- qf$sample
  qf <- qf[rownames(caa$annotation), , drop = FALSE]
  
  all_families <- qf$Quinolone_families %>%
    strsplit(";", fixed = TRUE) %>%
    unlist() %>%
    trimws() %>%
    unique()
  
  all_families <- sort(all_families[all_families != ""])
  added_cols <- character(0)
  
  for (fam in all_families) {
    present <- grepl(fam, qf$Quinolone_families, fixed = TRUE)
    col_name <- fam
    
    caa$annotation[[col_name]] <- factor(
      ifelse(present, "yes", "no"),
      levels = c("yes", "no")
    )
    
    yes_color <- if (fam == "QRDR") "orange" else "yellow"
    
    caa$annotation_colors[[col_name]] <- c(
      "yes" = yes_color,
      "no" = "white"
    )
    
    added_cols <- c(added_cols, col_name)
  }
  
  caa <- reorder_presence_annotations_by_color(caa, added_cols)
  caa
}


decorate_with_aminoglycoside_family_presence <- function(caa, genotypeGroupTable) {
  
  agf <- genotypeGroupTable %>%
    dplyr::select(sample, Aminoglycoside_families) %>%
    dplyr::mutate(
      sample = as.character(sample),
      Aminoglycoside_families = dplyr::if_else(
        is.na(Aminoglycoside_families), "", Aminoglycoside_families
      )
    )
  
  rownames(agf) <- agf$sample
  agf <- agf[rownames(caa$annotation), , drop = FALSE]
  
  all_families <- agf$Aminoglycoside_families %>%
    strsplit(";", fixed = TRUE) %>%
    unlist() %>%
    trimws() %>%
    unique()
  
  all_families <- sort(all_families[all_families != ""])
  added_cols <- character(0)
  
  for (fam in all_families) {
    present <- grepl(fam, agf$Aminoglycoside_families, fixed = TRUE)
    col_name <- fam
    
    caa$annotation[[col_name]] <- factor(
      ifelse(present, "yes", "no"),
      levels = c("yes", "no")
    )
    
    yes_color <- dplyr::case_when(
      fam %in% c("AAC(3)", "AAC(6)") ~ "red",
      grepl("^APH", fam) ~ "orange",
      fam %in% c("AAD", "ANT") ~ "yellow",
      TRUE ~ "grey70"
    )
    
    caa$annotation_colors[[col_name]] <- c(
      "yes" = yes_color,
      "no" = "white"
    )
    
    added_cols <- c(added_cols, col_name)
  }
  
  caa <- reorder_presence_annotations_by_color(caa, added_cols)
  caa
}

decorate_with_functional_group_presence <- function(caa, genotypeGroupTable) {
  
  fg <- genotypeGroupTable %>%
    dplyr::select(sample, Functional_groups) %>%
    dplyr::mutate(
      sample = as.character(sample),
      Functional_groups = dplyr::if_else(
        is.na(Functional_groups), "", Functional_groups
      )
    )
  
  rownames(fg) <- fg$sample
  fg <- fg[rownames(caa$annotation), , drop = FALSE]
  
  all_groups <- fg$Functional_groups %>%
    strsplit(";", fixed = TRUE) %>%
    unlist() %>%
    trimws() %>%
    unique()
  
  all_groups <- sort(all_groups[all_groups != ""])
  added_cols <- character(0)
  
  get_group_color <- function(grp) {
    if (grepl("^3", grp)) return("darkred")
    if (grp == "1") return("orange")
    if (grp == "2be") return("yellow")
    if (grp %in% c("2b", "2br", "2d")) return("grey70")
    "white"
  }
  
  for (grp in all_groups) {
    present <- grepl(grp, fg$Functional_groups, fixed = TRUE)
    col_name <- grp
    
    caa$annotation[[col_name]] <- factor(
      ifelse(present, "yes", "no"),
      levels = c("yes", "no")
    )
    
    caa$annotation_colors[[col_name]] <- c(
      "yes" = get_group_color(grp),
      "no" = "white"
    )
    
    added_cols <- c(added_cols, col_name)
  }
  
  caa <- reorder_presence_annotations_by_color(caa, added_cols)
  caa
}

decorate_with_beta_gene_presence <- function(caa,
                                             genotypeGroupTable,
                                             mapping_table,
                                             gene_col = "Gene_symbol",
                                             functional_group_col = "Functional_group") {
  
  bg <- genotypeGroupTable %>%
    dplyr::select(sample, Beta_genes) %>%
    dplyr::mutate(
      sample = as.character(sample),
      Beta_genes = dplyr::if_else(
        is.na(Beta_genes), "", Beta_genes
      )
    )
  
  rownames(bg) <- bg$sample
  bg <- bg[rownames(caa$annotation), , drop = FALSE]
  
  # Build gene -> functional group lookup
  gene_map <- mapping_table %>%
    dplyr::select(
      gene = dplyr::all_of(gene_col),
      functional_group = dplyr::all_of(functional_group_col)
    ) %>%
    dplyr::mutate(
      gene = trimws(as.character(gene)),
      functional_group = trimws(as.character(functional_group))
    )
  
  gene_to_fg <- stats::setNames(gene_map$functional_group, gene_map$gene)
  
  all_genes <- bg$Beta_genes %>%
    strsplit(";", fixed = TRUE) %>%
    unlist() %>%
    trimws() %>%
    unique()
  
  all_genes <- sort(all_genes[all_genes != ""])
  added_cols <- character(0)
  
  get_fg_color <- function(fg) {
    if (is.na(fg) || fg == "" || fg == "NA") return("white")
    if (grepl("^3", fg)) return("darkred")
    if (fg == "1") return("orange")
    if (fg == "2be") return("yellow")
    if (fg %in% c("2b", "2br", "2d")) return("grey70")
    "white"
  }
  
  for (gene in all_genes) {
    present <- grepl(gene, bg$Beta_genes, fixed = TRUE)
    col_name <- gene
    
    fg <- unname(gene_to_fg[gene])
    yes_color <- get_fg_color(fg)
    
    caa$annotation[[col_name]] <- factor(
      ifelse(present, "yes", "no"),
      levels = c("yes", "no")
    )
    
    caa$annotation_colors[[col_name]] <- c(
      "yes" = yes_color,
      "no" = "white"
    )
    
    added_cols <- c(added_cols, col_name)
  }
  
  caa <- reorder_presence_annotations_by_color(caa, added_cols)
  caa
}

decorate_with_aminoglycoside_gene_presence <- function(caa,
                                                       genotypeGroupTable,
                                                       geneMappingTable) {
  
  ag <- genotypeGroupTable %>%
    dplyr::select(sample, Aminoglycoside_genes) %>%
    dplyr::mutate(
      sample = as.character(sample),
      Aminoglycoside_genes = dplyr::if_else(
        is.na(Aminoglycoside_genes), "", Aminoglycoside_genes
      )
    )
  
  rownames(ag) <- ag$sample
  ag <- ag[rownames(caa$annotation), , drop = FALSE]
  
  gene_map <- geneMappingTable %>%
    dplyr::select(Gene_symbol, class, subclass) %>%
    dplyr::mutate(
      Gene_symbol = trimws(as.character(Gene_symbol)),
      class = trimws(as.character(class)),
      subclass = trimws(as.character(subclass))
    )
  
  gene_to_class <- stats::setNames(gene_map$class, gene_map$Gene_symbol)
  gene_to_subclass <- stats::setNames(gene_map$subclass, gene_map$Gene_symbol)
  
  all_genes <- ag$Aminoglycoside_genes %>%
    strsplit(";", fixed = TRUE) %>%
    unlist() %>%
    trimws() %>%
    unique()
  
  all_genes <- sort(all_genes[all_genes != ""])
  added_cols <- character(0)
  
  get_ag_color <- function(gene) {
    g <- trimws(gene)
    g_lower <- tolower(g)
    
    mapped_class <- toupper(unname(gene_to_class[g]))
    mapped_subclass <- toupper(unname(gene_to_subclass[g]))
    
    if (grepl("^aac\\(", g_lower)) return("red")
    if (grepl("^aph\\(", g_lower)) return("orange")
    if (grepl("^aad", g_lower)) return("yellow")
    if (grepl("^ant\\(", g_lower)) return("yellow")
    
    # fallback from mapped text if raw naming is odd
    if (grepl("AMINOGLYCOSIDE", mapped_class, fixed = TRUE)) {
      if (grepl("AAC", toupper(g), fixed = TRUE)) return("red")
      if (grepl("APH", toupper(g), fixed = TRUE)) return("orange")
      if (grepl("AAD", toupper(g), fixed = TRUE)) return("yellow")
      if (grepl("ANT", toupper(g), fixed = TRUE)) return("yellow")
    }
    
    if (grepl("AAC", mapped_subclass, fixed = TRUE)) return("red")
    if (grepl("APH", mapped_subclass, fixed = TRUE)) return("orange")
    if (grepl("AAD", mapped_subclass, fixed = TRUE)) return("yellow")
    if (grepl("ANT", mapped_subclass, fixed = TRUE)) return("yellow")
    
    "grey70"
  }
  
  for (gene in all_genes) {
    present <- grepl(gene, ag$Aminoglycoside_genes, fixed = TRUE)
    col_name <- gene
    
    caa$annotation[[col_name]] <- factor(
      ifelse(present, "yes", "no"),
      levels = c("yes", "no")
    )
    
    caa$annotation_colors[[col_name]] <- c(
      "yes" = get_ag_color(gene),
      "no" = "white"
    )
    
    added_cols <- c(added_cols, col_name)
  }
  
  caa <- reorder_presence_annotations_by_color(caa, added_cols)
  caa
}

decorate_with_quinolone_gene_presence <- function(caa,
                                                  genotypeGroupTable,
                                                  geneMappingTable) {
  
  qg <- genotypeGroupTable %>%
    dplyr::select(sample, Quinolone_genes) %>%
    dplyr::mutate(
      sample = as.character(sample),
      Quinolone_genes = dplyr::if_else(
        is.na(Quinolone_genes), "", Quinolone_genes
      )
    )
  
  rownames(qg) <- qg$sample
  qg <- qg[rownames(caa$annotation), , drop = FALSE]
  
  gene_map <- geneMappingTable %>%
    dplyr::select(Gene_symbol, class, subclass) %>%
    dplyr::mutate(
      Gene_symbol = trimws(as.character(Gene_symbol)),
      class = trimws(as.character(class)),
      subclass = trimws(as.character(subclass))
    )
  
  gene_to_class <- stats::setNames(gene_map$class, gene_map$Gene_symbol)
  gene_to_subclass <- stats::setNames(gene_map$subclass, gene_map$Gene_symbol)
  
  all_genes <- qg$Quinolone_genes %>%
    strsplit(";", fixed = TRUE) %>%
    unlist() %>%
    trimws() %>%
    unique()
  
  all_genes <- sort(all_genes[all_genes != ""])
  added_cols <- character(0)
  
  get_q_color <- function(gene) {
    g <- trimws(gene)
    g_upper <- toupper(g)
    
    mapped_class <- toupper(unname(gene_to_class[g]))
    mapped_subclass <- toupper(unname(gene_to_subclass[g]))
    
    # QRDR mutations often won't be in the gene map as AMR genes
    if (grepl("GYRA_|PARC_|PARE_|GYRB_", g_upper)) return("orange")
    if (g_upper == "QRDR") return("orange")
    
    # PMQR genes / mixed AMINOGLYCOSIDE-QUINOLONE genes
    if (grepl("^QNR", g_upper)) return("yellow")
    if (grepl("^QEPA", g_upper)) return("yellow")
    if (grepl("QUINOLONE", mapped_class, fixed = TRUE)) return("yellow")
    if (grepl("QUINOLONE", mapped_subclass, fixed = TRUE)) return("yellow")
    
    "grey70"
  }
  
  for (gene in all_genes) {
    present <- grepl(gene, qg$Quinolone_genes, fixed = TRUE)
    col_name <- gene
    
    caa$annotation[[col_name]] <- factor(
      ifelse(present, "yes", "no"),
      levels = c("yes", "no")
    )
    
    caa$annotation_colors[[col_name]] <- c(
      "yes" = get_q_color(gene),
      "no" = "white"
    )
    
    added_cols <- c(added_cols, col_name)
  }
  
  caa <- reorder_presence_annotations_by_color(caa, added_cols)
  caa
}


reorder_presence_annotations_by_color <- function(caa,
                                                  new_cols,
                                                  color_order = c("grey70", "yellow", "orange", "red", "darkred")) {
  new_cols <- intersect(new_cols, colnames(caa$annotation))
  if (length(new_cols) == 0) return(caa)
  
  yes_cols <- sapply(new_cols, function(col) {
    col_map <- caa$annotation_colors[[col]]
    if (!is.null(col_map) && "yes" %in% names(col_map)) unname(col_map[["yes"]]) else NA_character_
  }, USE.NAMES = TRUE)
  
  color_rank <- match(yes_cols, color_order)
  color_rank[is.na(color_rank)] <- length(color_order) + 1
  
  ord <- order(color_rank, new_cols)
  new_cols_ordered <- new_cols[ord]
  
  old_cols <- setdiff(colnames(caa$annotation), new_cols)
  caa$annotation <- caa$annotation[, c(old_cols, new_cols_ordered), drop = FALSE]
  
  caa
}


aggregate_presence_by_color <- function(caa,
                                        decorate_fun,
                                        ...,
                                        label_map = NULL,
                                        prefix = NULL,
                                        drop_original = TRUE,
                                        no_color = "white") {
  stopifnot(is.function(decorate_fun))
  
  old_ann_cols <- colnames(caa$annotation)
  old_color_cols <- names(caa$annotation_colors)
  
  # Apply decorator
  caa2 <- decorate_fun(caa, ...)
  
  new_ann_cols <- setdiff(colnames(caa2$annotation), old_ann_cols)
  new_color_cols <- setdiff(names(caa2$annotation_colors), old_color_cols)
  target_cols <- intersect(new_ann_cols, new_color_cols)
  
  if (length(target_cols) == 0) {
    warning("Decorator did not add any new colored annotation columns.")
    return(caa2)
  }
  
  # yes-color for each new presence column
  yes_colors <- sapply(target_cols, function(col) {
    col_map <- caa2$annotation_colors[[col]]
    if (!("yes" %in% names(col_map))) return(NA_character_)
    unname(col_map[["yes"]])
  }, USE.NAMES = TRUE)
  
  keep <- !is.na(yes_colors) & yes_colors != no_color
  target_cols <- target_cols[keep]
  yes_colors <- yes_colors[keep]
  
  if (length(target_cols) == 0) {
    warning("No aggregatable colored presence columns found after excluding no_color.")
    return(caa2)
  }
  
  color_groups <- split(target_cols, yes_colors)
  rename_after_drop <- character(0)
  aggregated_cols <- character(0)
  
  make_unique_name <- function(x, existing) {
    if (!(x %in% existing)) return(x)
    i <- 2
    cand <- paste0(x, "_", i)
    while (cand %in% existing) {
      i <- i + 1
      cand <- paste0(x, "_", i)
    }
    cand
  }
  
  for (clr in names(color_groups)) {
    cols <- color_groups[[clr]]
    
    desired_name <- if (!is.null(label_map) && clr %in% names(label_map)) {
      label_map[[clr]]
    } else {
      clr
    }
    
    if (!is.null(prefix)) {
      desired_name <- paste0(prefix, desired_name)
    }
    
    if (isTRUE(drop_original) && desired_name %in% cols) {
      out_name <- make_unique_name(
        paste0(".__tmp__.", desired_name),
        colnames(caa2$annotation)
      )
      rename_after_drop[out_name] <- desired_name
    } else {
      out_name <- make_unique_name(desired_name, colnames(caa2$annotation))
    }
    
    any_yes <- apply(
      caa2$annotation[, cols, drop = FALSE],
      1,
      function(x) any(as.character(x) == "yes", na.rm = TRUE)
    )
    
    caa2$annotation[[out_name]] <- factor(
      ifelse(any_yes, "yes", "no"),
      levels = c("yes", "no")
    )
    
    caa2$annotation_colors[[out_name]] <- c(
      "yes" = clr,
      "no" = no_color
    )
    
    aggregated_cols <- c(aggregated_cols, out_name)
  }
  
  if (isTRUE(drop_original)) {
    caa2$annotation <- caa2$annotation[, setdiff(colnames(caa2$annotation), target_cols), drop = FALSE]
    caa2$annotation_colors[target_cols] <- NULL
    
    if (length(rename_after_drop) > 0) {
      for (tmp_name in names(rename_after_drop)) {
        final_name <- rename_after_drop[[tmp_name]]
        
        colnames(caa2$annotation)[colnames(caa2$annotation) == tmp_name] <- final_name
        caa2$annotation_colors[[final_name]] <- caa2$annotation_colors[[tmp_name]]
        caa2$annotation_colors[[tmp_name]] <- NULL
        
        aggregated_cols[aggregated_cols == tmp_name] <- final_name
      }
    }
  }
  
  # order aggregated columns by yes-color: grey70, yellow, orange, red, darkred
  caa2 <- reorder_presence_annotations_by_color(caa2, aggregated_cols)
  
  caa2
}

# ============================================================
# Plot helpers
# make_annotation_name_strip <- function(labels, angle = 90, base_size = 10) {
#   df <- data.frame(
#     x = seq_along(labels),
#     y = 1,
#     lab = labels,
#     stringsAsFactors = FALSE
#   )
#   
#   ggplot2::ggplot(df, ggplot2::aes(x, y, label = lab)) +
#     ggplot2::geom_text(
#       angle = angle,
#       hjust = 1,
#       vjust = 0.5,
#       size = base_size / 3
#     ) +
#     ggplot2::scale_x_continuous(
#       limits = c(0.5, length(labels) + 0.5),
#       expand = c(0, 0)
#     ) +
#     ggplot2::coord_cartesian(clip = "off") +
#     ggplot2::theme_void() +
#     ggplot2::theme(
#       plot.margin = ggplot2::margin(0, 2, 0, 2)
#     )
# }

# get_annotation_track_names <- function(annotation_row, exclude = "Cluster") {
#   labs <- colnames(annotation_row)
#   labs <- setdiff(labs, exclude)
#   c(labs, if (exclude %in% colnames(annotation_row)) exclude)
# }


# wrap_pheatmap_with_annotation_names <- function(ph, annotation_labels, tag = NULL, strip_height = 0.10) {
#   body <- patchwork::wrap_elements(full = ph$gtable, clip = FALSE)
#   
#   if (!is.null(tag)) {
#     body <- body +
#       ggplot2::labs(title = tag) +
#       ggplot2::theme(
#         plot.title = ggplot2::element_text(face = "bold", hjust = 0, size = 18),
#         plot.margin = ggplot2::margin(2, 2, 2, 2)
#       )
#   }
#   
#   strip <- make_annotation_name_strip(annotation_labels)
#   
#   body / strip + patchwork::plot_layout(heights = c(1, strip_height))
# }

make_cluster_plot_pca <- function(caa, title = NULL) {

  p <- fviz_cluster(
    list(data = caa$data, cluster = caa$clusters),
    palette = unlist(caa$annotation_colors$Cluster),
    ellipse.type = "convex",
    geom = "point",
    show.clust.cent = TRUE
  ) +
    ggtitle(title %||% "")
  
  # extract % variance from PCA
  pca <- prcomp(caa$data, scale. = TRUE)
  var <- 100 * (pca$sdev^2 / sum(pca$sdev^2))
  
  p + 
    labs(
      x = sprintf("PC1 (%.1f%%)", var[1]),
      y = sprintf("PC2 (%.1f%%)", var[2])
    )
  
}

make_cluster_plot_umap <- function(caa, title = NULL, seed = 123) {
  set.seed(seed)
  
  um <- uwot::umap(
    as.matrix(caa$data),
    n_components = 2
  )
  
  colnames(um) <- c("UMAP1", "UMAP2")
  
  fviz_cluster(
    list(data = um, cluster = caa$clusters),
    palette = unlist(caa$annotation_colors$Cluster),
    ellipse.type = "convex",
    geom = "point",
    show.clust.cent = TRUE
  ) +
    labs(
      title = title,
      x = "UMAP1",
      y = "UMAP2"
    )
}


make_cluster_plot <- function(caa, title = NULL) {
  make_cluster_plot_pca(caa,title)
}


`%||%` <- function(x, y) if (is.null(x)) y else x




reorder_hclust_by_weights <- function(hc, weights) {
  dend <- as.dendrogram(hc)
  dend <- reorder(dend, wts = weights, agglo.FUN = mean)
  as.hclust(dend)
}

make_row_order_callback <- function(esbl_named_vector, esbl_priority) {
  force(esbl_named_vector)
  force(esbl_priority)
  
  function(hc, mat) {
    rn <- rownames(mat)
    
    esbl <- esbl_named_vector[rn]
    esbl_rank <- unname(esbl_priority[as.character(esbl)])
    
    # fallback if something is missing
    esbl_rank[is.na(esbl_rank)] <- max(esbl_priority, na.rm = TRUE) + 1
    
    # low mean resistance => higher up
    mm_mean <- rowMeans(mat, na.rm = TRUE)
    
    # ESBL should dominate, mm only breaks ties
    weights <- esbl_rank * 1000 + mm_mean
    
    reorder_hclust_by_weights(hc, weights = weights)
  }
}

make_pheatmap <- function(mat,
                          annotation_row = NULL,
                          annotation_colors = NULL,
                          color = gradient_red(),
                          show_rownames = FALSE,
                          show_colnames = TRUE,
                          cluster_rows = TRUE,
                          cluster_cols = TRUE,
                          legend = FALSE,
                          display_numbers = NULL,
                          fontsize_row = 4,
                          fontsize_col = 10,
                          fontsize_number = 8,
                          clustering_callback = NULL,
                          annotation_names_row = FALSE) {
  
  args <- list(
    mat = mat,
    clustering_method = "ward.D2",
    annotation_row = annotation_row,
    annotation_colors = annotation_colors,
    color = color,
    show_rownames = show_rownames,
    show_colnames = show_colnames,
    cluster_rows = cluster_rows,
    cluster_cols = cluster_cols,
    legend = legend,
    border_color = NA,
    fontsize_row = fontsize_row,
    fontsize_col = fontsize_col,
    fontsize_number = fontsize_number,
    main = "",
    annotation_names_row = annotation_names_row
  )
  
  if (!is.null(display_numbers)) {
    args$display_numbers <- display_numbers
  }
  
  if (!is.null(clustering_callback)) {
    args$clustering_callback <- clustering_callback
  }
  
  do.call(pheatmap::pheatmap, args)
}

# ============================================================
# Choosing k
# ============================================================

estimate_optimal_number_of_clusters <- function(data_matrix, max_k = 10, seed = 123) {
  set.seed(seed)
  
  pv = pvclust(
    t(data_matrix),
    method.hclust = "ward.D2",
    method.dist = "euclidean",
    nboot = 10)
  plot(pv)    
  
  library(pvclust)
  list(
    silhouette = fviz_nbclust(data_matrix, hcut, method = "silhouette", hc_method = "ward.D2") +
      labs(subtitle = "Silhouette method"),
    gap = fviz_nbclust(data_matrix, hcut, method = "gap_stat", nboot = 50, hc_method = "ward.D2") +
      labs(subtitle = "Gap statistic method"),
    wss = fviz_nbclust(data_matrix, hcut, method = "wss", hc_method = "ward.D2") +
      labs(subtitle = "Elbow method"),
    pv
    
  )
}

# ============================================================
# Main workflow
# ============================================================

make_cluster_and_heatmaps <- function(data_dir = ".",
                                      primary_table = "RESCALEDMM",
                                      k = 8,
                                      add_esbl = TRUE) {
  dat <- load_cluster_data(data_dir)
  tables <- fetch_tables(dat)
  
  stopifnot(primary_table %in% names(tables))
  
  primary <- tables[[primary_table]]
  caa <- clusters_and_annotation(primary, k = k)

  if(k==4){
    cluster_order <- c(3, 4, 1, 2)
    caa <- renumber_clusters_by_order(caa, cluster_order)
  }

  if(k==5){
    cluster_order <- c(3, 4, 1, 2, 5)
    caa <- renumber_clusters_by_order(caa, cluster_order)
  }
  if(k==6){
    cluster_order <- c(4,5,1,3,2, 6)
    caa <- renumber_clusters_by_order(caa, cluster_order)
  }
  
  cluster_plot <- make_cluster_plot(caa)
  #cluster_plot <- make_cluster_plot_ggplot(caa,label_esbl = TRUE)

  #Save caa with only clusters 
  caaBasic <- caa
  
  #
  if (add_esbl) {
    caa <- decorate_with_esbl(caa, dat)
  }
  esbl_vec <- caa$annotation$ESBL
  names(esbl_vec) <- rownames(caa$annotation)
  
  row_callback <- make_row_order_callback(
    esbl_named_vector = esbl_vec,
    esbl_priority = ESBL_PRIORITY
  )
  
  row_names_ordered <- order_rows_by_cluster_esbl_resistance(
    caa = caa,
    mat = primary
  )

  
  
  
  primary_heatmap <- make_pheatmap(
    mat = primary[row_names_ordered, , drop = FALSE],
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = rev(gradient_red()),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = TRUE,
    clustering_callback = row_callback
  )
  
  row_order <- row_names_ordered

  # SIR heatmap with ATU stars
  sir_tbl <- tables$SIR
  atu_tbl <- read_atu_antibiotics_model(dat) %>% drop_sample_column()
  
  display_numbers <- matrix(
    ifelse(as.matrix(atu_tbl), "\u2217", ""),
    nrow = nrow(atu_tbl),
    dimnames = dimnames(atu_tbl)
  )
  
  sir_heatmap <- make_pheatmap(
    mat = sir_tbl[row_order, , drop = FALSE],
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, , drop = FALSE]
  )

  caaD <- caa
  
  
  
  
  combined_1 <- (
    (cluster_plot + panel_box_theme) +
      (wrap_pheatmap(primary_heatmap) & panel_box_theme) + 
      (wrap_pheatmap(sir_heatmap) & panel_box_theme)
  ) +
    plot_layout(ncol = 3) +
    plot_annotation(tag_levels = "A")
  
  caa <- caaBasic
  genotypeGroupTable <- getGenotypeGroupTable()
  
  #caa <- decorate_with_functional_group_presence(caa = caa,genotypeGroupTable = genotypeGroupTable)
  caa <- aggregate_presence_by_color(
    caa = caa,
    decorate_fun = decorate_with_functional_group_presence,
    genotypeGroupTable = genotypeGroupTable,
    label_map = c("darkred" = "ESBL carba", "orange" = "AMPC", "yellow" = "ESBL classic", "grey70" = "Non-ESBL")
  )
  caaC <- caa
  print(colnames(caa$annotation))
  
  beta_cols <- intersect(BETA_LACTAMS, colnames(primary))
  
  primary_heatmap_betalactams <- make_pheatmap(
    mat = primary[row_order, beta_cols, drop = FALSE], 
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = rev(gradient_red()),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = TRUE
  )

  caa <- caaBasic
  #caa <- decorate_with_aminoglycoside_family_presence(caa = caa,genotypeGroupTable = genotypeGroupTable)
  caa <- aggregate_presence_by_color(
    caa = caa,
    decorate_fun = decorate_with_aminoglycoside_family_presence,
    genotypeGroupTable = genotypeGroupTable,
    label_map = c("red" = "AAC", "orange" = "APH", "yellow" = "AAD/ANT")
  )
  caaB <- caa
  
  ag_cols <- c("GEN","TOB")
  
  print(colnames(caa$annotation))
  primary_heatmap_aminoglycosides <- make_pheatmap(
    mat = primary[row_order, ag_cols, drop = FALSE],
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = rev(gradient_red()),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = TRUE
  )

  caa <- caaBasic

  caa <- aggregate_presence_by_color(
    caa = caa,
    decorate_fun = decorate_with_quinolone_family_presence,
    genotypeGroupTable = genotypeGroupTable,
    label_map = c(
      "orange" = "QRDR",
      "yellow" = "PMQR"
    ),
    drop_original = TRUE
  )
  #caa <- decorate_with_quinolone_family_presence(caa = caa,genotypeGroupTable = genotypeGroupTable)
  caaA <- caa
  print(colnames(caa$annotation))
  
  quinolones_cols <- c("CIP" ,"OFX" ,"LVX", "MFX")
  
  primary_heatmap_quinolones <- make_pheatmap(
    mat = primary[row_order, quinolones_cols, drop = FALSE], 
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = rev(gradient_red()),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = TRUE,
  )
  
  ph_list <- list(primary_heatmap_quinolones,
                  primary_heatmap_aminoglycosides,
                  primary_heatmap_betalactams,
                  sir_heatmap)

  
  combined_2 <- (
    (wrap_pheatmap(ph_list[[1]]) & panel_box_theme) +
      (wrap_pheatmap(ph_list[[2]]) & panel_box_theme) +
      (wrap_pheatmap(ph_list[[3]]) & panel_box_theme) +
      (wrap_pheatmap(ph_list[[4]]) & panel_box_theme)
  ) +
    plot_layout(ncol = 4) +
    plot_annotation(tag_levels = "A")
     
  
  
  
  caa <- caaBasic
  caa <- decorate_with_quinolone_family_presence(genotypeGroupTable = genotypeGroupTable,caa = caa) 
  sir_heatmap_quinolones_family <- make_pheatmap(
    mat = sir_tbl[row_order, quinolones_cols, drop = FALSE], 
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, quinolones_cols, drop = FALSE],
    annotation_names_row = TRUE
  )
  
  caa <- caaBasic
  caa <- decorate_with_aminoglycoside_family_presence(genotypeGroupTable = genotypeGroupTable,caa = caa) 
  sir_heatmap_aminoglycosides_family <- make_pheatmap(
    mat = sir_tbl[row_order, ag_cols, drop = FALSE], 
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, ag_cols, drop = FALSE],
    annotation_names_row = TRUE
  )
  
  caa <- caaBasic
  caa <- decorate_with_functional_group_presence(genotypeGroupTable = genotypeGroupTable,caa = caa) 
  sir_heatmap_betalactams_bj <- make_pheatmap(
    mat = sir_tbl[row_order, beta_cols, drop = FALSE], 
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, beta_cols, drop = FALSE],
    annotation_names_row = TRUE
  )
  
  
  geneMappingTable <- getGeneMappingTable()
  
  caa <- caaBasic
  caa <- decorate_with_beta_gene_presence(caa = caa,
                                   genotypeGroupTable = genotypeGroupTable,
                                   mapping_table = geneMappingTable)
  caa <- decorate_with_esbl(caa,dat)
  
  sir_heatmap_betalactam_gene <- make_pheatmap(
    mat = sir_tbl[row_order, beta_cols, drop = FALSE], 
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, beta_cols, drop = FALSE],
    annotation_names_row = TRUE
  )
  
  caa <- caaBasic
  caa <- decorate_with_aminoglycoside_gene_presence(caa = caa,
                                          genotypeGroupTable = genotypeGroupTable,
                                          geneMappingTable = geneMappingTable)

  sir_heatmap_aminoglycoside_gene <- make_pheatmap(
    mat = sir_tbl[row_order, ag_cols, drop = FALSE],
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, ag_cols, drop = FALSE],
    annotation_names_row = TRUE
  )
  caa <- caaBasic
  caa <- decorate_with_quinolone_gene_presence(caa = caa,
                                                    genotypeGroupTable = genotypeGroupTable,
                                               geneMappingTable = geneMappingTable)

  sir_heatmap_quinolone_gene <- make_pheatmap(
    mat = sir_tbl[row_order, quinolones_cols, drop = FALSE],
    annotation_row = caa$annotation,
    annotation_colors = caa$annotation_colors,
    color = gradient_green_yellow_red(),
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    legend = FALSE,
    display_numbers = display_numbers[row_order, quinolones_cols, drop = FALSE],
    annotation_names_row = TRUE
  )
  
  
  

  list(
    data = dat,
    tables = tables,
    cluster = caa,
    k = k,
    row_order = row_order,
    cluster_plot = cluster_plot,
    primary_heatmap = primary_heatmap,
    sir_heatmap = sir_heatmap,
    combined_phenotype_cluster_primary_sir = combined_1,
    combined_genotype_aggregated_sir = combined_2,
    sir_heatmap_betalactam_gene = (wrap_pheatmap(sir_heatmap_betalactam_gene) & panel_box_theme),
    sir_heatmap_aminoglycoside_gene =  (wrap_pheatmap(sir_heatmap_aminoglycoside_gene) & panel_box_theme),
    sir_heatmap_quinolone_gene =  (wrap_pheatmap(sir_heatmap_quinolone_gene) & panel_box_theme)
  )
}




ESTIMATE <- function()
{
  data <- load_cluster_data(processedRootRcommon)
  tables <- fetch_tables(data)

#  estimate_optimal_number_of_clusters(tables$MM)
#  estimate_optimal_number_of_clusters(tables$RESCALEDMM)
  estimate_optimal_number_of_clusters(tables$MM)
}
  

ALL <- function()
{
  # create clustering using hclust
  # rotating dendrogram to get clusters
  #
  result <- make_cluster_and_heatmaps(
    data_dir = processedRootRcommon,
    primary_table = "MM",
    k = 6,
    add_esbl = TRUE
  )
  
  clusterInformation <- tibble(
    sample = result$data$mm_full_rescaled$sample,
    roworder = result$row_order,
    cluster = result$cluster$annotation$Cluster,
    ESBL = result$cluster$annotation$ESBL
  )
  clusterInformation %>% 
    write.csv2(
      file.path(processedRootRcluster,
                sprintf("phenotype_cluster%d.csv",result$k))
                ,row.names = FALSE)

  
  ggplot2::ggsave(
    filename = file.path(processedRootRcluster,
                         sprintf("cluster_phenotype%d.png",result$k)),
    plot = result$combined_phenotype_cluster_primary_sir,
    width = 13,
    height = 8,
    dpi = 300
  )
  print(result$combined_phenotype_cluster_primary_sir)
  
  ggplot2::ggsave(
    filename = file.path(processedRootRcluster,
                         sprintf("genotype_aggregated_sir%d.png",result$k)),
    plot = result$combined_genotype_aggregated_sir,
    width = 15,
    height = 8,
    dpi = 300
  )
  
  print(result$combined_genotype_aggregated_sir)

  
  ggplot2::ggsave(
    filename = file.path(processedRootRcluster,
                         sprintf("genotype_betalactam_sir%d.png",result$k)),
    plot = result$sir_heatmap_betalactam_gene,
    width = 13,
    height = 8,
    dpi = 300
  )

  ggplot2::ggsave(
    filename = file.path(processedRootRcluster,
                         sprintf("genotype_aminoglycoside_sir%d.png",result$k)),
    plot = result$sir_heatmap_aminoglycoside_gene,
    width = 13,
    height = 8,
    dpi = 300
  )

  ggplot2::ggsave(
    filename = file.path(processedRootRcluster,
                         sprintf("genotype_quinolone_sir%d.png",result$k)),
    plot = result$sir_heatmap_quinolone_gene,
    width = 13,
    height = 8,
    dpi = 300
  )
  
}



